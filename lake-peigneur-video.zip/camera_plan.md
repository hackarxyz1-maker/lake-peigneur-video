# Camera plan (1080x1920, 30 fps, 80 degree vertical FOV)
Times come from the real sentence/word timings of the uploaded voice-over. Positions are local to each location.
Every move ends at rest (monotone cubic time warp), depth of field is focused at the look-at distance.

| Shot | Time | Location | Camera path | Foreground / midground / background | In-world labels |
|---|---|---|---|---|---|
| 1-2 | 0.00-10.93 | Lake shore | high crane down to the sign, track right to the dock and fisherman, swing to the garden gate | reeds / sign, dock, fisherman, rowboats / tree line, sky | LAKE PEIGNEUR, LIVE OAK GARDENS |
| 3 | 10.93-15.85 | Salt mine cutaway | from the lake slab down to the miners, left to the banner, back up to the lake above | timber posts / miners, cart / brick arches | SALT MINE 1919 (unrolls on "nineteen nineteen") |
| 4 | 15.85-20.26 | Oil rig | wide, push to the crate, crane up the derrick, push to the crew on "stuck" | buoy and boat / crew, crate / derrick, trees | NOV 20, 1980 (pops in on "november") |
| 5 | 20.26-25.19 | Cross-section | wide, push to the bit, down into the mine, back up to the draining lake | hanging lantern / bit, miners / lake slab | none |
| 6 | 25.19-32.80 | Whirlpool | high wide, orbit around the funnel as rig, barges, tug, land and island are swallowed | reeds / funnel / tree line | none |
| 7 | 32.80-38.43 | Canal | sign, track along the flow, board with arrow, canal mouth | reeds / sign, barge, fisherman / banks | DELCAMBRE CANAL, arrow drawn on "backward", FROM THE GULF |
| 8 | 38.43-43.20 | Refilling crater | high look-down, lower toward the water, barges pop up | reeds / barges / trees | TWO DAYS, two dashed frames for the two missing barges |
| 9 | 43.20-48.11 | New lake | slow push toward the depth pole, which sinks as the water turns salty | banner poles / pole / tree line | 10 FT, DEEPEST LAKE IN LOUISIANA |
| 10 | 48.11-51.71 | Office | push toward the desk and ledger | plant / boss, clerk, ledger / window | DIAMOND CRYSTAL SALT CO., SETTLED $32,000,000 |
| 11 | 51.71-54.80 | Evening lake | from the empty dock, crane back and up to a wide shot | reeds / dock / lake and trees | none |
