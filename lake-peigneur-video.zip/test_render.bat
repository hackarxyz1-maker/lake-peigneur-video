@echo off
cd /d "%~dp0"
call npm install
if not exist out mkdir out
call npx remotion render src/index.jsx LakeStory out\test.mp4 --frames=0-29 --gl=angle --concurrency=4 --image-format=jpeg --jpeg-quality=92 --crf=17
echo.
echo Test done: out\test.mp4 (first 30 frames)
pause
