@echo off
cd /d "%~dp0"
call npm install
if errorlevel 1 goto :fail
if not exist out mkdir out
call npx remotion render src/index.jsx LakeStory out\full_silent.mp4 --gl=angle --concurrency=4 --image-format=jpeg --jpeg-quality=92 --crf=17
if errorlevel 1 goto :fail
call npx remotion ffmpeg -y -i out\full_silent.mp4 -i public\mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest final.mp4
echo.
echo Done: final.mp4 (1080x1920, voice-over + sound effects)
pause
exit /b 0
:fail
echo Something failed. Send me the text above.
pause
