# Sound effect cues (all synthesised in code, synced to the voice-over)

| Time | Cue |
|---|---|
|  0.00 s | lake water + wind bed |
|  1.10 s | birds |
|  7.00 s | dock creak |
|  8.10 s | reel click on "fishing" |
|  8.62 s | line plops in water |
| 10.71 s | cut whoosh |
| 10.93 s | mine drone |
| 11.40 s | cave drips |
| 11.95 s | pickaxe taps while "miners had dug salt" |
| 13.15 s | banner unrolls on "nineteen nineteen" |
| 14.00 s | ore cart rumble |
| 15.63 s | cut whoosh |
| 15.90 s | diesel engine chug |
| 16.20 s | crate thump on "november" |
| 19.15 s | rope strains, metal clunk on "stuck" |
| 20.04 s | cut whoosh |
| 20.35 s | drill grinds down |
| 21.65 s | break-through crack on "through" |
| 21.70 s | water rushes into the mine |
| 24.97 s | cut whoosh |
| 25.20 s | whirlpool roar builds |
| 26.90 s | rig groans and sinks |
| 27.45 s | barges knock and sink |
| 28.45 s | tugboat horn on "tugboat" |
| 29.90 s | land crumbles on "acres of land" |
| 31.60 s | island collapses on "island" |
| 32.58 s | cut whoosh |
| 32.90 s | canal water flows |
| 35.45 s | flow reverses on "now it ran" |
| 36.25 s | arrow drawn on "backward" |
| 37.00 s | water pours in on "pouring" |
| 38.21 s | cut whoosh |
| 38.40 s | lake refills (trickle to rush) |
| 38.70 s | banner "two days" |
| 40.90 s | nine barges pop up, one bloop each |
| 42.98 s | cut whoosh |
| 44.90 s | depth pole sinks on "salt water" |
| 46.90 s | banner unrolls on "Louisiana" |
| 47.89 s | cut whoosh |
| 48.10 s | office room tone |
| 49.42 s | ledger stamp on "thirty" |
| 49.90 s | coin clinks on "million" |
| 51.49 s | cut whoosh |
| 51.70 s | evening crickets, soft |
