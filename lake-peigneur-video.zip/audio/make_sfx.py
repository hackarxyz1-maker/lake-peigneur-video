"""Synthesises every sound effect in code (no downloaded files) and mixes it under the uploaded voice-over.
Every cue is placed on a word time from sentence_times / the alignment of the voice-over."""
import numpy as np, subprocess, sys, wave
from scipy import signal

SR = 44100
vo_path = '../public/voiceover.wav'
raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', vo_path, '-f', 'f32le', '-ac', '1', '-ar', str(SR), '-'], capture_output=True).stdout
vo = np.frombuffer(raw, dtype=np.float32).copy()
N = len(vo) + SR // 2            # a little tail
buf = np.zeros(N, dtype=np.float64)
rng = np.random.default_rng(7)
cues = []

def T(n): return np.arange(n) / SR
def add(t, sig, gain=1.0):
    i = int(t * SR); j = min(N, i + len(sig))
    if i < N and j > i: buf[i:j] += sig[:j - i] * gain
def noise(n): return rng.standard_normal(n)
def bp(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], btype='band', fs=SR, output='sos'); return signal.sosfilt(sos, x)
def lp(x, f, order=2): return signal.sosfilt(signal.butter(order, f, btype='low', fs=SR, output='sos'), x)
def hp(x, f, order=2): return signal.sosfilt(signal.butter(order, f, btype='high', fs=SR, output='sos'), x)
def env_pts(pts, n):
    tt = T(n); xs = [p[0] for p in pts]; ys = [p[1] for p in pts]; return np.interp(tt, xs, ys)
def adsr(n, a=0.01, d=0.2, s=0.0, r=0.1):
    e = np.ones(n); na, nd, nr = int(a * SR), int(d * SR), int(r * SR)
    e[:na] = np.linspace(0, 1, max(na, 1)); 
    if nd > 0: e[na:na + nd] = np.linspace(1, s, nd)[:max(0, min(nd, n - na))]
    e[na + nd:] = s
    if nr > 0: e[-nr:] *= np.linspace(1, 0, nr)
    return e
def decay(n, tau): return np.exp(-T(n) / tau)
def sweep_noise(dur, f0, f1, q=0.6, gain_env=None):
    n = int(dur * SR); out = np.zeros(n); x = noise(n); blk = 1024; zi = None
    for b in range(0, n, blk):
        f = f0 + (f1 - f0) * (b / n); lo = max(40, f * (1 - q / 2)); hi = min(SR / 2 - 100, f * (1 + q / 2))
        sos = signal.butter(2, [lo, hi], btype='band', fs=SR, output='sos')
        if zi is None: zi = np.zeros((sos.shape[0], 2))
        y, zi = signal.sosfilt(sos, x[b:b + blk], zi=zi); out[b:b + blk] = y
    return out * (gain_env if gain_env is not None else 1)
def cue(t, name): cues.append((t, name))

# ---------- reusable sounds ----------
def water_bed(t0, t1, g=0.05, f=(180, 900)):
    n = int((t1 - t0) * SR); x = bp(noise(n), *f)
    lfo = 0.6 + 0.4 * np.sin(2 * np.pi * 0.23 * T(n) + rng.uniform(0, 6)) * np.sin(2 * np.pi * 0.11 * T(n) + 1)
    e = env_pts([(0, 0), (0.6, 1), (t1 - t0 - 0.6, 1), (t1 - t0, 0)], n)
    add(t0, x * lfo * e, g)
def wind(t0, t1, g=0.03):
    n = int((t1 - t0) * SR); x = lp(noise(n), 500); lfo = 0.5 + 0.5 * np.sin(2 * np.pi * 0.17 * T(n) + rng.uniform(0, 6))
    add(t0, x * lfo * env_pts([(0, 0), (0.8, 1), (t1 - t0 - 0.8, 1), (t1 - t0, 0)], n), g)
def bird(t, f0=3200, n_chirps=3):
    for k in range(n_chirps):
        d = 0.09; n = int(d * SR); ff = np.linspace(f0, f0 * 1.35, n); ph = 2 * np.pi * np.cumsum(ff) / SR
        add(t + k * 0.14, np.sin(ph) * np.sin(np.pi * np.linspace(0, 1, n)) ** 2, 0.05)
def whoosh(t0, d=0.55, g=0.09):
    n = int(d * SR); e = np.sin(np.pi * np.linspace(0, 1, n)) ** 2
    add(t0, sweep_noise(d, 500, 3500, 0.9, e), g * 6)
def tink(t, f=2200, g=0.12):
    n = int(0.35 * SR); tt = T(n)
    s = (np.sin(2 * np.pi * f * tt) + 0.6 * np.sin(2 * np.pi * f * 1.51 * tt)) * np.exp(-tt / 0.07)
    s += hp(noise(n), 3000) * np.exp(-tt / 0.01) * 0.5; add(t, s, g)
def thump(t, f=80, g=0.4, d=0.22):
    n = int(d * 3 * SR); tt = T(n); s = np.sin(2 * np.pi * (f * (1 + 0.6 * np.exp(-tt / 0.03))) * tt) * np.exp(-tt / d)
    s += lp(noise(n), 400) * np.exp(-tt / 0.04) * 0.4; add(t, s, g)
def splash(t, g=0.3, d=0.45, lo=700, hi=4500):
    n = int(d * 3 * SR); tt = T(n); add(t, bp(noise(n), lo, hi) * np.exp(-tt / d) * (1 + 0.3 * np.sin(2 * np.pi * 14 * tt)), g)
def bloop(t, f0=280, f1=720, g=0.18):
    n = int(0.25 * SR); tt = T(n); ph = 2 * np.pi * np.cumsum(np.linspace(f0, f1, n)) / SR
    add(t, np.sin(ph) * np.exp(-tt / 0.08), g)
def creak(t, d=0.9, f0=170, f1=260, g=0.1):
    n = int(d * SR); tt = T(n); f = np.linspace(f0, f1, n) * (1 + 0.04 * np.sin(2 * np.pi * 23 * tt)); ph = 2 * np.pi * np.cumsum(f) / SR
    s = (signal.sawtooth(ph) * 0.5 + np.sin(ph)) * np.sin(np.pi * np.linspace(0, 1, n)) ** 1.5; add(t, lp(s, 1400), g)
def horn(t, d=1.0, g=0.16):
    n = int(d * SR); tt = T(n); s = sum(signal.sawtooth(2 * np.pi * f * tt) * a for f, a in [(196, 1), (294, 0.7), (392, 0.35)])
    add(t, lp(s, 1200) * adsr(n, 0.06, 0.1, 0.8, 0.25), g)
def cloth(t, d=0.8, g=0.1):
    n = int(d * SR); e = np.sin(np.pi * np.linspace(0, 1, n)) ** 2; add(t, sweep_noise(d, 1200, 2600, 1.0, e), g * 5)
def chalk(t, d=0.8, g=0.07):
    n = int(d * SR); x = hp(noise(n), 2500) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 38 * T(n)))) * adsr(n, 0.03, 0.05, 0.9, 0.1); add(t, x, g)
def gulp(t, g=0.3):
    n = int(0.4 * SR); tt = T(n); ph = 2 * np.pi * np.cumsum(np.linspace(420, 80, n)) / SR; add(t, np.sin(ph) * np.exp(-tt / 0.18), g)
def clink(t, g=0.1):
    n = int(0.3 * SR); tt = T(n); s = (np.sin(2 * np.pi * 3100 * tt) + 0.7 * np.sin(2 * np.pi * 4700 * tt)) * np.exp(-tt / 0.06); add(t, s, g)
def paper(t, d=0.5, g=0.06):
    n = int(d * SR); x = bp(noise(n), 2500, 7000) * (rng.random(n) > 0.55) * np.exp(-T(n) / (d * 0.6)); add(t, x, g)
def rumble(t0, t1, g=0.2, f=90, shape=None):
    n = int((t1 - t0) * SR); x = lp(noise(n), f, 3)
    e = shape(T(n)) if shape else env_pts([(0, 0), (0.3, 1), ((t1 - t0) - 0.4, 1), (t1 - t0, 0)], n)
    add(t0, x * e, g * 4)

# =============== timeline (seconds from the voice-over) ===============
# Shots 1-2: lake
water_bed(0, 11.6, 0.05); wind(0, 11.6, 0.035); cue(0, 'lake water + wind bed')
for tb, f in [(1.1, 3300), (3.4, 3700), (7.3, 3100)]: bird(tb, f)
cue(1.1, 'birds')
creak(7.0, 0.8, 150, 210, 0.07); cue(7.0, 'dock creak')
tink(8.1, 1800, 0.07); cue(8.1, 'reel click on "fishing"'); splash(8.62, 0.12, 0.25); cue(8.62, 'line plops in water')
# whoosh at the cream dips (location changes)
for tc in [10.93, 15.85, 20.26, 25.19, 32.80, 38.43, 43.20, 48.11, 51.71]:
    whoosh(tc - 0.22); cue(tc - 0.22, 'cut whoosh')
# Shot 3: mine
n3 = int(5.3 * SR); drone = (np.sin(2 * np.pi * 55 * T(n3)) + 0.5 * np.sin(2 * np.pi * 82.4 * T(n3))) * env_pts([(0, 0), (0.5, 1), (4.7, 1), (5.3, 0)], n3)
add(10.9, drone, 0.06); cue(10.93, 'mine drone')
for tt, f in [(11.2, 1500), (12.6, 1800), (14.1, 1300), (15.4, 1650)]: tink(tt, f, 0.05) if False else None
for k, tt in enumerate([11.95, 12.45, 12.95, 13.55]): tink(tt, 2300 if k % 2 == 0 else 2050, 0.13)
cue(11.95, 'pickaxe taps while "miners had dug salt"')
for tt in [11.4, 13.0, 14.7]: bloop(tt, 1700, 1500, 0.05)
cue(11.4, 'cave drips')
cloth(13.15, 0.8, 0.1); cue(13.15, 'banner unrolls on "nineteen nineteen"')
# cart rumble
nc = int(1.6 * SR); cart = lp(noise(nc), 140) * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 5.5 * T(nc)))) * env_pts([(0, 0), (0.2, 1), (1.3, 1), (1.6, 0)], nc); add(14.0, cart, 0.35); cue(14.0, 'ore cart rumble')
# Shot 4: rig
water_bed(15.9, 20.3, 0.05, (160, 700)); wind(15.9, 20.3, 0.04)
nE = int(4.4 * SR); pulse = (np.sin(2 * np.pi * 58 * T(nE)) * (0.5 + 0.5 * np.sin(2 * np.pi * 7 * T(nE)) ** 2)) + 0.3 * lp(noise(nE), 220)
add(15.9, pulse * env_pts([(0, 0), (0.5, 1), (3.8, 1), (4.4, 0)], nE), 0.07); cue(15.9, 'diesel engine chug')
thump(16.2, 70, 0.28); cue(16.2, 'crate thump on "november"')
tink(16.9, 900, 0.07); tink(17.7, 1100, 0.06)
creak(18.2, 0.9, 140, 190, 0.07)
creak(19.2, 1.0, 130, 280, 0.16); thump(19.55, 55, 0.45, 0.3); tink(19.6, 700, 0.15); cue(19.15, 'rope strains, metal clunk on "stuck"')
# Shot 5: cross-section
nd = int(1.45 * SR); tt = T(nd); f = np.linspace(80, 190, nd); ph = 2 * np.pi * np.cumsum(f) / SR
grind = signal.sawtooth(ph) * 0.4 + bp(noise(nd), 600, 1800) * 0.7; add(20.35, grind * env_pts([(0, 0), (0.2, 0.6), (1.3, 1), (1.45, 0.8)], nd), 0.18); cue(20.35, 'drill grinds down')
nb = int(0.12 * SR); add(21.65, noise(nb) * np.exp(-T(nb) / 0.02), 0.55); thump(21.66, 45, 0.9, 0.5); cue(21.65, 'break-through crack on "through"')
rush = lambda tt_: np.clip((tt_ - 0.0) / 1.2, 0, 1) * (1.0 - 0.0 * tt_)
nR = int((25.6 - 21.7) * SR); xr = hp(noise(nR), 500) * env_pts([(0, 0.0), (0.4, 0.8), (3.9, 1.2)], nR); add(21.7, xr, 0.2); cue(21.7, 'water rushes into the mine')
rumble(21.7, 25.8, 0.3, 70)
for tt_ in [22.6, 23.4, 24.3]: gulp(tt_, 0.18)
# Shot 6: whirlpool
nW = int((33.4 - 25.2) * SR); xw = sweep_noise(8.2, 260, 520, 0.9)
xw *= (0.7 + 0.3 * np.sin(2 * np.pi * 0.9 * T(nW))) * env_pts([(0, 0.0), (1.5, 1.0), (7.0, 1.2), (8.2, 0.0)], nW); add(25.2, xw, 0.5); cue(25.2, 'whirlpool roar builds')
rumble(25.4, 33.2, 0.2, 60)
creak(26.5, 1.0, 120, 330, 0.18); splash(27.0, 0.45, 0.8); cue(26.9, 'rig groans and sinks')
for k, tt_ in enumerate(np.arange(27.45, 29.0, 0.22)): thump(tt_, 75 - k * 4, 0.28, 0.2)
cue(27.45, 'barges knock and sink')
horn(28.45, 1.1, 0.2); cue(28.45, 'tugboat horn on "tugboat"')
for tt_ in [28.9, 29.2]: splash(tt_, 0.3, 0.5)
nL = int(1.9 * SR); xl = lp(noise(nL), 320) * (0.4 + 0.6 * (rng.random(nL // 2000 + 2).repeat(2000)[:nL])) * env_pts([(0, 0), (0.2, 1), (1.6, 1), (1.9, 0)], nL); add(29.9, xl, 0.6); cue(29.9, 'land crumbles on "acres of land"')
splash(30.6, 0.4, 0.6); splash(31.2, 0.4, 0.7)
nI = int(1.4 * SR); add(31.5, lp(noise(nI), 250) * env_pts([(0, 0), (0.2, 1), (1.1, 1), (1.4, 0)], nI), 0.9); splash(32.3, 0.5, 0.9); cue(31.6, 'island collapses on "island"')
# Shot 7: canal
water_bed(32.9, 38.4, 0.07, (200, 1100)); cue(32.9, 'canal water flows')
gulp(35.45, 0.3); whoosh(35.5, 0.7, 0.07); cue(35.45, 'flow reverses on "now it ran"')
chalk(36.25, 0.8, 0.08); cue(36.25, 'arrow drawn on "backward"')
nP = int(1.4 * SR); add(37.0, hp(noise(nP), 450) * env_pts([(0, 0), (0.3, 1), (1.4, 1)], nP), 0.12); cue(37.0, 'water pours in on "pouring"')
cloth(37.4, 0.6, 0.06)
# Shot 8: refill
nr = int(5.0 * SR); tr = T(nr)
trickle = bp(noise(nr), 500, 3000) * (1 + 0.6 * np.sin(2 * np.pi * (3 + 3 * tr / 5) * tr)) * env_pts([(0, 0.2), (2.0, 1.0), (3.0, 0.6), (5.0, 0.1)], nr); add(38.4, trickle, 0.1); cue(38.4, 'lake refills (trickle to rush)')
rumble(38.5, 41.0, 0.12, 80)
cloth(38.7, 0.6, 0.06); cue(38.7, 'banner "two days"')
for i in range(9):
    tt_ = 40.9 + 0.22 * i + 0.1; bloop(tt_, 260 + 15 * i, 700 + 30 * i, 0.16); thump(tt_ + 0.12, 95, 0.12, 0.12)
cue(40.9, 'nine barges pop up, one bloop each')
# Shot 9: new lake
water_bed(43.2, 48.2, 0.05, (160, 700)); wind(43.2, 48.2, 0.03); bird(44.0, 3500, 2)
gulp(44.9, 0.28); cue(44.9, 'depth pole sinks on "salt water"'); gulp(45.8, 0.2)
cloth(46.9, 0.8, 0.1); cue(46.9, 'banner unrolls on "Louisiana"')
# Shot 10: office
n10 = int(3.6 * SR); add(48.1, np.sin(2 * np.pi * 120 * T(n10)) * env_pts([(0, 0), (0.4, 1), (3.2, 1), (3.6, 0)], n10), 0.02); cue(48.1, 'office room tone')
paper(48.6, 0.5, 0.07); tink(49.0, 1200, 0.05)
thump(49.42, 100, 0.35, 0.12); cue(49.42, 'ledger stamp on "thirty"')
for k, tt_ in enumerate([49.9, 50.05, 50.22, 50.4]): clink(tt_, 0.1 + 0.02 * k)
cue(49.9, 'coin clinks on "million"'); paper(50.6, 0.6, 0.06)
# Shot 11: evening
water_bed(51.7, 54.9, 0.045); wind(51.7, 54.9, 0.03)
ncr = int(3.1 * SR); cr = np.sin(2 * np.pi * 4300 * T(ncr)) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 21 * T(ncr)))) * (0.5 + 0.5 * np.sin(2 * np.pi * 3 * T(ncr)))
add(51.7, cr * env_pts([(0, 0), (0.6, 1), (2.4, 1), (3.1, 0)], ncr), 0.012); cue(51.7, 'evening crickets, soft')
bird(52.6, 3000, 2)

# =============== mix ===============
sfx = buf[:len(vo)] if len(buf) >= len(vo) else np.pad(buf, (0, len(vo) - len(buf)))
speech = np.abs(vo) > 0.02
vrms = np.sqrt(np.mean(vo[speech] ** 2)) if speech.any() else 0.1
srms = np.sqrt(np.mean(sfx ** 2)) + 1e-9
sfx_scaled = sfx * (0.42 * vrms / srms)
mix = np.zeros(N); mix[:len(vo)] += vo; mix[:len(sfx_scaled)] += sfx_scaled
mix = mix[:len(vo) + SR // 4]
# light fade out, gentle soft clip, peak limit
fade = int(0.4 * SR); mix[-fade:] *= np.linspace(1, 0, fade)
mix = np.tanh(mix * 1.1) / np.tanh(1.1); pk = np.max(np.abs(mix)); mix = mix / max(pk, 1e-9) * 0.93
with wave.open('mix.wav', 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype('<i2').tobytes())
sf = sfx_scaled / (np.max(np.abs(sfx_scaled)) + 1e-9) * 0.8
with wave.open('sfx_only.wav', 'wb') as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((sf * 32767).astype('<i2').tobytes())
with open('sfx_cues.md', 'w') as f:
    f.write('# Sound effect cues (all synthesised in code, synced to the voice-over)\n\n| Time | Cue |\n|---|---|\n')
    for t, n in sorted(cues): f.write(f'| {t:5.2f} s | {n} |\n')
print('voice rms', round(float(vrms), 4), 'sfx rms before scale', round(float(srms), 5), 'peak', round(float(pk), 3), 'dur', len(mix) / SR)
