import React, { useMemo } from 'react';
import * as THREE from 'three';
import { useCurrentFrame } from 'remotion';
import { INK, wornTex, signTex, toonMat, hullMat, makeHull, archGeo, wallWithOpenings, rng, makeWaterMaterial } from './kit.js';

export const clamp01 = x => Math.max(0, Math.min(1, x));
export const ease = x => { x = clamp01(x); return x * x * (3 - 2 * x); };
export const seg = (t, a, b) => clamp01((t - a) / (b - a));
export const useT = () => useCurrentFrame() / 30;

// ---------- geometry cache ----------
const geoCache = new Map();
function getGeo(kind, args) {
  const key = kind + JSON.stringify(args);
  if (geoCache.has(key)) return geoCache.get(key);
  let g;
  if (kind === 'box') g = new THREE.BoxGeometry(...args);
  else if (kind === 'cyl') g = new THREE.CylinderGeometry(args[0], args[1], args[2], args[3] || 12);
  else if (kind === 'cone') g = new THREE.ConeGeometry(args[0], args[1], args[2] || 10);
  else if (kind === 'sphere') g = new THREE.SphereGeometry(args[0], args[1] || 14, args[2] || 10);
  else if (kind === 'arch') g = archGeo(...args);
  else if (kind === 'wall') g = wallWithOpenings(args[0], args[1], args[2], args[3]);
  else if (kind === 'boat') g = boatGeo(args[0], args[1], args[2]);
  geoCache.set(key, g); g.userData.hull = null; return g;
}
function boatGeo(len, wid, height) {
  const s = new THREE.Shape(); const L = len / 2, Wd = wid / 2;
  s.moveTo(-L, 0); s.quadraticCurveTo(-L * 0.5, Wd * 1.05, 0, Wd); s.quadraticCurveTo(L * 0.55, Wd, L, 0); s.quadraticCurveTo(L * 0.55, -Wd, 0, -Wd); s.quadraticCurveTo(-L * 0.5, -Wd * 1.05, -L, 0);
  const g = new THREE.ExtrudeGeometry(s, { depth: height, bevelEnabled: false, curveSegments: 10 });
  g.rotateX(-Math.PI / 2); return g;
}
const hullCache = new Map();
function getHull(geo) { if (!hullCache.has(geo)) hullCache.set(geo, makeHull(geo)); return hullCache.get(geo); }

// ---------- the one building block: toon mesh + ink outline ----------
export function Solid({ kind = 'box', args = [1, 1, 1], color = '#c9a87a', tex = null, pos = [0, 0, 0], rot = [0, 0, 0], scale = [1, 1, 1], outline = true, shadow = true, basic = false, opacity = 1 }) {
  const geo = getGeo(kind, args);
  const hull = outline ? getHull(geo) : null;
  const mat = useMemo(() => basic ? new THREE.MeshBasicMaterial({ color, toneMapped: false }) : (opacity < 1 ? new THREE.MeshToonMaterial({ color, map: tex, gradientMap: toonMat(color).gradientMap, transparent: true, opacity }) : toonMat(color, tex)), [color, tex, basic, opacity]);
  return (
    <group position={pos} rotation={rot} scale={scale}>
      <mesh geometry={geo} material={mat} castShadow={shadow} receiveShadow />
      {outline && <mesh geometry={hull} material={hullMat} />}
    </group>
  );
}

// cylinder beam between two points
export function Beam({ a, b, r = 0.12, color = '#7a5a3a', tex = null, outline = true }) {
  const va = new THREE.Vector3(...a), vb = new THREE.Vector3(...b);
  const mid = va.clone().add(vb).multiplyScalar(0.5); const len = va.distanceTo(vb);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), vb.clone().sub(va).normalize());
  const e = new THREE.Euler().setFromQuaternion(q);
  return <Solid kind="cyl" args={[r, r, len, 8]} pos={mid.toArray()} rot={[e.x, e.y, e.z]} color={color} tex={tex} outline={outline} />;
}
export function Plank({ a, b, w = 0.25, h = 0.12, color = '#8a6038', tex = null }) {
  const va = new THREE.Vector3(...a), vb = new THREE.Vector3(...b);
  const mid = va.clone().add(vb).multiplyScalar(0.5); const len = va.distanceTo(vb);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1, 0, 0), vb.clone().sub(va).normalize());
  const e = new THREE.Euler().setFromQuaternion(q);
  return <Solid kind="box" args={[len, h, w]} pos={mid.toArray()} rot={[e.x, e.y, e.z]} color={color} tex={tex} />;
}

// ---------- painted labels that live in the world ----------
export function Label({ text, lines = null, w = 4, h = 1, pos = [0, 0, 0], rot = [0, 0, 0], bg = '#e9d9b0', fg = '#3a2418', font, border = true, tw = 1024, th = 256 }) {
  const tex = useMemo(() => signTex(text, { bg, fg, w: tw, h: th, border, lines, ...(font ? { font } : {}) }), [text, bg, fg, lines && lines.join('|')]);
  return (
    <mesh position={pos} rotation={rot} renderOrder={2}>
      <planeGeometry args={[w, h]} />
      <meshBasicMaterial map={tex} toneMapped={false} />
    </mesh>
  );
}
// sign on two posts
export function PostSign({ text, pos = [0, 0, 0], w = 6, h = 1.6, postH = 4.2, rotY = 0, lines = null, th = 256, tw = 1024, sink = 0.5 }) {
  const wood = wornTex('#8a6038', 'planks', 4, [1, 2]);
  return (
    <group position={pos} rotation={[0, rotY, 0]}>
      <Solid kind="box" args={[0.34, postH + sink, 0.34]} pos={[-w / 2 + 0.2, (postH - sink) / 2, 0]} tex={wood} color="#8a6038" />
      <Solid kind="box" args={[0.34, postH + sink, 0.34]} pos={[w / 2 - 0.2, (postH - sink) / 2, 0]} tex={wood} color="#8a6038" />
      <Solid kind="box" args={[w, h, 0.22]} pos={[0, postH - h / 2 - 0.35, 0]} tex={wornTex('#caa772', 'planks', 9, [2, 1])} color="#caa772" />
      <Label text={text} lines={lines} w={w - 0.3} h={h - 0.3} pos={[0, postH - h / 2 - 0.35, 0.125]} tw={tw} th={th} />
    </group>
  );
}
// banner hung between two poles; progress 0..1 unrolls it
export function Banner({ text, lines = null, th = 256, pos = [0, 0, 0], w = 6, h = 1.5, poleH = 4.5, progress = 1, rotY = 0, bg = '#d9c7a0' }) {
  const wood = wornTex('#7a5a3a', 'planks', 6, [1, 3]);
  const p = ease(progress);
  return (
    <group position={pos} rotation={[0, rotY, 0]}>
      <Solid kind="box" args={[0.28, poleH, 0.28]} pos={[-w / 2 - 0.15, poleH / 2, 0]} tex={wood} color="#7a5a3a" />
      <Solid kind="box" args={[0.28, poleH, 0.28]} pos={[w / 2 + 0.15, poleH / 2, 0]} tex={wood} color="#7a5a3a" />
      <Solid kind="box" args={[w + 0.6, 0.18, 0.2]} pos={[0, poleH - 0.4, 0]} color="#5a3f28" />
      <group position={[0, poleH - 0.5, 0.05]} scale={[1, Math.max(0.001, p), 1]}>
        <Label text={text} lines={lines} w={w} h={h} pos={[0, -h / 2, 0]} bg={bg} th={th} tw={1024} />
      </group>
    </group>
  );
}
export function Crate({ pos = [0, 0, 0], s = 1, label = null, rotY = 0, color = '#a47642', labelP = 1 }) {
  const wood = wornTex(color, 'planks', 12, [1, 1]);
  return (
    <group position={pos} rotation={[0, rotY, 0]}>
      <Solid kind="box" args={[s, s, s]} pos={[0, s / 2, 0]} tex={wood} color={color} />
      <Solid kind="box" args={[s * 1.02, 0.08, s * 1.02]} pos={[0, 0.06, 0]} color="#5a3f28" />
      <Solid kind="box" args={[s * 1.02, 0.08, s * 1.02]} pos={[0, s - 0.06, 0]} color="#5a3f28" />
      {label && labelP > 0.01 && <group position={[0, s * 0.5, s / 2 + 0.01]} scale={[ease(labelP), ease(labelP), 1]}><Label text={label} w={s * 0.86} h={s * 0.4} pos={[0, 0, 0]} tw={512} th={256} font='bold 80px Georgia, "DejaVu Serif", serif' /></group>}
    </group>
  );
}
export function Barrel({ pos = [0, 0, 0], s = 1 }) {
  return (<group position={pos}>
    <Solid kind="cyl" args={[0.55 * s, 0.5 * s, 1.1 * s, 12]} pos={[0, 0.55 * s, 0]} tex={wornTex('#8a5a30', 'planks', 21, [3, 1])} color="#8a5a30" />
    <Solid kind="cyl" args={[0.58 * s, 0.58 * s, 0.07 * s, 12]} pos={[0, 0.3 * s, 0]} color="#3a3a42" />
    <Solid kind="cyl" args={[0.58 * s, 0.58 * s, 0.07 * s, 12]} pos={[0, 0.85 * s, 0]} color="#3a3a42" />
  </group>);
}
export function Lantern({ pos = [0, 0, 0] }) {
  return (<group position={pos}>
    <Solid kind="cyl" args={[0.02, 0.02, 1.2, 4]} pos={[0, 0.6, 0]} color="#222" outline={false} />
    <Solid kind="box" args={[0.34, 0.46, 0.34]} color="#ffd98a" basic pos={[0, 0, 0]} />
    <pointLight color="#ffcf80" intensity={9} distance={9} position={[0, 0, 0.4]} />
  </group>);
}

// ---------- nature ----------
export function Oak({ pos = [0, 0, 0], s = 1, seed = 1 }) {
  const R = rng(seed); const bark = wornTex('#6a4a30', 'planks', 31, [1, 3]);
  return (<group position={pos} scale={s}>
    <Solid kind="cyl" args={[0.5, 0.8, 4.2, 8]} pos={[0, 2.1, 0]} tex={bark} color="#6a4a30" />
    <Solid kind="sphere" args={[2.7, 12, 9]} pos={[0, 5.4, 0]} color="#5d8a4a" />
    <Solid kind="sphere" args={[2.0, 12, 9]} pos={[-2.1, 4.7, 0.5]} color="#6a9a54" />
    <Solid kind="sphere" args={[2.2, 12, 9]} pos={[2.0, 4.9, -0.4]} color="#527f44" />
    <Solid kind="cyl" args={[0.07, 0.04, 1.8, 4]} pos={[-1.5, 3.1, 1.4]} color="#9aa88a" outline={false} />
    <Solid kind="cyl" args={[0.07, 0.04, 2.2, 4]} pos={[1.4, 3.3, 1.3]} color="#9aa88a" outline={false} />
  </group>);
}
export function Cypress({ pos = [0, 0, 0], s = 1 }) {
  return (<group position={pos} scale={s}>
    <Solid kind="cyl" args={[0.7, 1.2, 4, 7]} pos={[0, 2, 0]} color="#6a5240" outline={false} />
    <Solid kind="cone" args={[2.6, 9, 8]} pos={[0, 8, 0]} color="#4d7650" outline={false} />
  </group>);
}
export function Reeds({ pos = [0, 0, 0], n = 9, seed = 2, s = 1 }) {
  const R = rng(seed);
  return (<group position={pos}>
    {Array.from({ length: n }).map((_, i) => {
      const x = (R() - .5) * 1.8, z = (R() - .5) * 1.4, h = (1.6 + R() * 1.4) * s, lean = (R() - .5) * 0.35;
      return (<group key={i} position={[x, 0, z]} rotation={[0, 0, lean]}>
        <Solid kind="cyl" args={[0.04, 0.05, h, 5]} pos={[0, h / 2, 0]} color="#7e8f4c" outline={false} />
        {i % 2 === 0 && <Solid kind="cyl" args={[0.1, 0.1, 0.5, 6]} pos={[0, h, 0]} color="#6a4328" />}
      </group>);
    })}
  </group>);
}
export function TreeRing({ r = 58, n = 30, y = 0, arc = [0, Math.PI * 2], seed = 5 }) {
  const R = rng(seed);
  return (<group>
    {Array.from({ length: n }).map((_, i) => {
      const a = arc[0] + (arc[1] - arc[0]) * (i / n) + (R() - .5) * 0.12, rr = r + (R() - .5) * 10;
      return <Cypress key={i} pos={[Math.cos(a) * rr, y, Math.sin(a) * rr]} s={0.8 + R() * 0.7} />;
    })}
  </group>);
}
export function Ground({ size = [200, 200], pos = [0, -0.5, 0], color = '#7c9a55', pattern = 'grass', rep = [30, 30] }) {
  return <Solid kind="box" args={[size[0], 1, size[1]]} pos={pos} tex={wornTex(color, pattern, 8, rep)} color={color} outline={false} />;
}

// ---------- water ----------
export function Water({ pos = [0, 0, 0], size = [200, 120], drain = 0, center = [0, 0], flow = [0, 0], colors = null, scale = 0.5, segs = [2, 2] }) {
  const t = useT();
  const mat = useMemo(() => makeWaterMaterial(...(colors || [])), []);
  mat.uniforms.uTime.value = t; mat.uniforms.uDrain.value = drain; mat.uniforms.uCenter.value.set(center[0], center[1]);
  mat.uniforms.uFlow.value.set(flow[0], flow[1]); mat.uniforms.uScale.value = scale;
  if (colors) { mat.uniforms.uC1.value.set(colors[0]); mat.uniforms.uC2.value.set(colors[1]); mat.uniforms.uC3.value.set(colors[2]); }
  return (<mesh position={pos} rotation={[-Math.PI / 2, 0, 0]} material={mat} receiveShadow>
    <planeGeometry args={[size[0], size[1], segs[0], segs[1]]} />
  </mesh>);
}

// ---------- boats and rigs ----------
export function Rowboat({ pos = [0, 0, 0], rotY = 0, color = '#8a6a48' }) {
  return (<group position={pos} rotation={[0, rotY, 0]}>
    <Solid kind="boat" args={[3.4, 1.5, 0.6]} pos={[0, -0.1, 0]} color={color} tex={wornTex(color, 'planks', 5, [2, 1])} />
    <Solid kind="boat" args={[2.7, 1.1, 0.05]} pos={[0, 0.5, 0]} color="#4a3626" outline={false} />
    <Solid kind="box" args={[0.18, 0.1, 1.5]} pos={[0.2, 0.42, 0]} color="#a07a50" />
    <Solid kind="box" args={[0.18, 0.1, 1.5]} pos={[-0.7, 0.42, 0]} color="#a07a50" />
  </group>);
}
export function Barge({ pos = [0, 0, 0], rot = [0, 0, 0], color = '#8a4a3a' }) {
  return (<group position={pos} rotation={rot}>
    <Solid kind="box" args={[4.0, 0.9, 1.7]} pos={[0, 0.1, 0]} color={color} tex={wornTex(color, 'planks', 17, [3, 1])} />
    <Solid kind="box" args={[3.7, 0.08, 1.45]} pos={[0, 0.58, 0]} color="#5a4a40" outline={false} />
    <Solid kind="box" args={[0.9, 0.7, 1.0]} pos={[-1.2, 0.95, 0]} color="#d9cdb0" />
    <Solid kind="cyl" args={[0.1, 0.1, 0.5, 6]} pos={[1.5, 0.8, 0.5]} color="#2b2b30" />
    <Solid kind="cyl" args={[0.1, 0.1, 0.5, 6]} pos={[1.5, 0.8, -0.5]} color="#2b2b30" />
  </group>);
}
export function Tugboat({ pos = [0, 0, 0], rot = [0, 0, 0] }) {
  return (<group position={pos} rotation={rot}>
    <Solid kind="boat" args={[4.6, 2.0, 0.9]} pos={[0, -0.2, 0]} color="#3d5f7a" tex={wornTex('#3d5f7a', 'planks', 25, [3, 1])} />
    <Solid kind="box" args={[1.7, 1.2, 1.4]} pos={[-0.5, 1.2, 0]} color="#e6dcc3" />
    <Solid kind="box" args={[1.9, 0.14, 1.6]} pos={[-0.5, 1.85, 0]} color="#b03a3a" />
    <Solid kind="cyl" args={[0.3, 0.34, 1.2, 8]} pos={[-0.6, 2.5, 0]} color="#b03a3a" />
    <Solid kind="cyl" args={[0.32, 0.32, 0.2, 8]} pos={[-0.6, 3.1, 0]} color="#2b2b30" />
  </group>);
}
export function Derrick({ pos = [0, 0, 0], h = 9, tilt = [0, 0, 0], pipe = 1 }) {
  const wood = wornTex('#7a5a3a', 'planks', 33, [1, 4]);
  const hw = 1.5, tw = 0.45;
  const legs = [[-hw, -hw], [hw, -hw], [hw, hw], [-hw, hw]];
  return (<group position={pos} rotation={tilt}>
    {legs.map((l, i) => <Beam key={i} a={[l[0], 0, l[1]]} b={[l[0] * tw / hw, h, l[1] * tw / hw]} r={0.16} color="#6a5a48" tex={wood} />)}
    {[0.25, 0.5, 0.75].map((f, i) => {
      const w = hw - (hw - tw) * f; const y = h * f;
      return (<group key={i}>
        <Beam a={[-w, y, -w]} b={[w, y, -w]} r={0.07} color="#7a6a58" /><Beam a={[w, y, -w]} b={[w, y, w]} r={0.07} color="#7a6a58" />
        <Beam a={[w, y, w]} b={[-w, y, w]} r={0.07} color="#7a6a58" /><Beam a={[-w, y, w]} b={[-w, y, -w]} r={0.07} color="#7a6a58" />
        <Beam a={[-w, y, w]} b={[w, y + h * 0.12, w]} r={0.05} color="#7a6a58" outline={false} />
      </group>);
    })}
    <Solid kind="box" args={[1.4, 0.6, 1.4]} pos={[0, h + 0.3, 0]} color="#4a4a52" />
    <Solid kind="cyl" args={[0.12, 0.12, h * 1.1 * pipe, 8]} pos={[0, h * 0.55 * pipe, 0]} color="#8a8a92" />
  </group>);
}
export function Dock({ pos = [0, 0, 0], len = 9, wid = 3.2, top = 0.55 }) {
  const wood = wornTex('#9a7048', 'planks', 41, [len / 3, 1]);
  return (<group position={pos}>
    <Solid kind="box" args={[wid, 0.25, len]} pos={[0, top, 0]} tex={wood} color="#9a7048" />
    {Array.from({ length: 5 }).map((_, i) => [-1, 1].map(sx => <Solid key={i + '' + sx} kind="cyl" args={[0.16, 0.18, 2.4, 7]} pos={[sx * (wid / 2 - 0.15), top - 1.0, -len / 2 + 0.6 + i * (len - 1.2) / 4]} color="#5a4030" />))}
  </group>);
}
export function SkyDome({ tex, pos }) {
  return (<mesh position={pos} renderOrder={-10}>
    <sphereGeometry args={[250, 24, 16]} />
    <meshBasicMaterial map={tex} side={THREE.BackSide} depthWrite={false} fog={false} toneMapped={false} />
  </mesh>);
}
