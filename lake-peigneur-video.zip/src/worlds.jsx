import React, { useMemo } from 'react';
import * as THREE from 'three';
import { useCurrentFrame } from 'remotion';
import { INK, wornTex, signTex, skyTex, toonMat } from './kit.js';
import { WX } from './camera.js';
import { Character } from './char.jsx';
import { Solid, Beam, Plank, Label, PostSign, Banner, Crate, Barrel, Lantern, Oak, Cypress, Reeds, TreeRing, Ground, Water, Rowboat, Barge, Tugboat, Derrick, Dock, clamp01, ease, seg, useT } from './parts.jsx';

const smooth = (a, b, x) => { x = clamp01((x - a) / (b - a)); return x * x * (3 - 2 * x); };
const funnelY = (drain, r) => { const f = drain * (1 - smooth(0, 11, r)); return -(f * f * 4.2 + f * 0.6); };
const backOut = x => { x = clamp01(x); const c = 1.9; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); };

const FRESH = ['#4f9a7e', '#72b896', '#b4dcc0'];
const SALT = ['#2f6f9c', '#4a8fba', '#8cc4de'];
const lerpCol = (a, b, u) => '#' + new THREE.Color(a).lerp(new THREE.Color(b), u).getHexString();

// ================= A: lake shore, sign, dock, garden gate (shots 1-2) =================
export function WorldA() {
  const t = useT();
  const brick = wornTex('#a6553f', 'bricks', 3, [1, 2]);
  const bob = k => Math.sin(t * 1.3 + k) * 0.05;
  return (<group position={[WX.A, 0, 0]}>
    <Water pos={[0, 0, -43]} size={[180, 94]} />
    <Ground size={[180, 80]} pos={[0, -0.48, 43.5]} />
    <TreeRing r={60} n={34} arc={[Math.PI, Math.PI * 2]} />
    <PostSign text="LAKE PEIGNEUR" pos={[0, 0, 0]} w={6.4} h={1.8} postH={4.4} sink={0.8} />
    <Dock pos={[11, 0, -0.7]} len={10} />
    <Character kind="fisher" pos={[11.3, 0.68, -3.2]} seed={1} />
    <Beam a={[12.0, 2.3, -3.0]} b={[14.2, 4.5, -6.0]} r={0.035} color="#a58a5a" outline={false} />
    <Beam a={[14.2, 4.5, -6.0]} b={[14.3, 0.4, -6.0]} r={0.012} color="#e8e2d0" outline={false} />
    <Rowboat pos={[6.3, bob(0), -3]} rotY={0.4} />
    <Rowboat pos={[15.9, bob(2), -4.6]} rotY={-0.3} color="#7a8a6a" />
    {/* garden gate */}
    <group position={[22, 0, 3.3]}>
      {[-3.3, 3.3].map(x => (<group key={x}>
        <Solid kind="box" args={[1.3, 5.2, 1.3]} pos={[x, 2.6, 0]} tex={brick} color="#a6553f" />
        <Solid kind="box" args={[1.7, 0.4, 1.7]} pos={[x, 5.4, 0]} color="#c9bfa8" />
        <Solid kind="sphere" args={[0.4, 10, 8]} pos={[x, 5.9, 0]} color="#c9bfa8" />
      </group>))}
      <Solid kind="box" args={[6.6, 0.3, 0.5]} pos={[0, 4.9, 0]} color="#4a3626" />
      <Solid kind="box" args={[5.4, 1.3, 0.22]} pos={[0, 4.1, 0.05]} tex={wornTex('#caa772', 'planks', 9, [2, 1])} color="#caa772" />
      <Label text="LIVE OAK GARDENS" w={5.1} h={1.0} pos={[0, 4.1, 0.18]} />
      {[[-5.6, 2], [5.4, 2.6], [-6.4, 4], [6.6, 4.5], [-4.8, 3.6]].map((p, i) => <Solid key={i} kind="sphere" args={[0.35, 8, 6]} pos={[p[0], 0.3, p[1]]} color={['#c8493f', '#e0b23a', '#c8493f', '#d9788a', '#e0b23a'][i]} />)}
    </group>
    <Oak pos={[16, 0, 8]} s={1.3} seed={2} /><Oak pos={[28.5, 0, 7]} s={1.4} seed={3} /><Oak pos={[-34, 0, 4]} s={1.6} seed={4} />
    <Reeds pos={[-5.6, 0, 7.2]} n={11} s={1.3} seed={4} /><Reeds pos={[4.8, 0, 5.2]} n={9} seed={7} /><Reeds pos={[17.5, 0, 6.2]} n={9} seed={9} />
  </group>);
}

// ================= B: salt mine cutaway under the lake (shot 3) =================
export function WorldB() {
  const t = useT();
  const bannerP = seg(t, 13.15, 13.95);
  const brick = wornTex('#b0583f', 'bricks', 5, [2, 1]);
  const timber = wornTex('#7a5a3a', 'planks', 6, [1, 3]);
  return (<group position={[WX.B, 0, 0]}>
    <Solid kind="box" args={[38, 3, 10]} pos={[0, 8, 0]} tex={wornTex("#4a93b3", "stones", 77, [3, 1])} color="#4a93b3" />
    <Water pos={[0, 9.52, 0]} size={[38, 10]} />
    <Rowboat pos={[-6, 9.8, 1]} rotY={0.3} />
    <Solid kind="box" args={[38, 2.6, 10]} pos={[0, 5.2, 0]} tex={wornTex('#8a6a48', 'stones', 11, [4, 1])} color="#8a6a48" />
    <Solid kind="box" args={[38, 1.2, 10]} pos={[0, -0.6, 0]} tex={wornTex('#ece0d8', 'salt', 12, [4, 1])} color="#ece0d8" />
    <Solid kind="box" args={[38, 3.9, 0.6]} pos={[0, 1.95, -4.7]} tex={wornTex('#5a4a42', 'stones', 13, [4, 1])} color="#5a4a42" />
    <Solid kind="box" args={[1, 3.9, 10]} pos={[-19, 1.95, 0]} color="#5a4a42" /><Solid kind="box" args={[1, 3.9, 10]} pos={[19, 1.95, 0]} color="#5a4a42" />
    {[-10, 0, 10].map(x => <Solid key={x} kind="arch" args={[6, 3.5, 0.5]} pos={[x, 0, -4.1]} tex={brick} color="#b0583f" />)}
    {[-10, 0, 10].map(x => <mesh key={'d' + x} position={[x, 1.6, -4.3]}><planeGeometry args={[5, 3.2]} /><meshBasicMaterial color="#1c1416" /></mesh>)}
    {[-13.5, 13.5].map(x => (<group key={x}>
      <Solid kind="box" args={[0.4, 3.9, 0.4]} pos={[x - 1.4, 1.95, -1]} tex={timber} color="#7a5a3a" /><Solid kind="box" args={[0.4, 3.9, 0.4]} pos={[x + 1.4, 1.95, -1]} tex={timber} color="#7a5a3a" />
      <Solid kind="box" args={[3.4, 0.4, 0.4]} pos={[x, 3.7, -1]} tex={timber} color="#7a5a3a" />
    </group>))}
    {[-7.6, 7.6].map(x => (<group key={'f' + x}>
      <Solid kind="box" args={[0.4, 3.9, 0.4]} pos={[x, 1.95, 3.4]} tex={timber} color="#7a5a3a" />
      <Solid kind="box" args={[0.4, 0.4, 3]} pos={[x, 3.7, 2]} tex={timber} color="#7a5a3a" />
    </group>))}
    {/* rails, cart and salt blocks */}
    <Solid kind="box" args={[24, 0.1, 0.12]} pos={[2, 0.06, 1.8]} color="#3a3a42" outline={false} /><Solid kind="box" args={[24, 0.1, 0.12]} pos={[2, 0.06, 0.8]} color="#3a3a42" outline={false} />
    <group position={[7.4, 0, 1.3]}>
      <Solid kind="box" args={[2.4, 0.9, 1.5]} pos={[0, 0.85, 0]} tex={timber} color="#6a4a30" />
      {[[-0.8, 0.8], [0.8, 0.8], [-0.8, -0.8], [0.8, -0.8]].map((p, i) => <Solid key={i} kind="cyl" args={[0.32, 0.32, 0.12, 10]} rot={[Math.PI / 2, 0, 0]} pos={[p[0], 0.33, p[1]]} color="#2b2b30" />)}
      {[[-0.5, 0], [0.5, 0], [0, 0.4]].map((p, i) => <Solid key={'s' + i} kind="box" args={[0.8, 0.7, 0.8]} pos={[p[0], 1.55 + (i === 2 ? 0.7 : 0), p[1] * 0.4]} color="#f1e6df" tex={wornTex('#f1e6df', 'salt', 14 + i, [1, 1])} />)}
    </group>
    {[[-15, -3], [-14, -3.4], [-15.2, -2.4]].map((p, i) => <Solid key={'b' + i} kind="box" args={[1.3, 1.1, 1.3]} pos={[p[0], 0.55 + (i === 2 ? 1.1 : 0), p[1]]} color="#f1e6df" tex={wornTex('#f1e6df', 'salt', 20 + i, [1, 1])} />)}
    <Character kind="miner" pos={[-3.6, 0, 0.6]} seed={1} /><Character kind="miner" pos={[0.4, 0, -0.7]} seed={2} pose="point" /><Character kind="miner" pos={[3.6, 0, 0.8]} seed={3} />
    <Beam a={[-4.3, 1.4, 1.3]} b={[-5.7, 3.1, 1.3]} r={0.05} color="#6a4a30" /><Solid kind="box" args={[0.9, 0.12, 0.12]} pos={[-5.9, 3.15, 1.3]} rot={[0, 0, 0.5]} color="#7a7a82" />
    <Banner text="SALT MINE · 1919" pos={[-9, 0, 1.6]} w={6} h={1.3} poleH={3.5} progress={bannerP} />
    <Lantern pos={[-5.5, 3.2, 0.5]} /><Lantern pos={[4.2, 3.2, -0.5]} />
  </group>);
}

// ================= C: oil rig on the lake (shot 4) =================
export function WorldC() {
  const t = useT();
  const deck = wornTex('#8a6038', 'planks', 51, [3, 2]);
  const shake = Math.sin(t * 13) * 0.02 * seg(t, 19.1, 19.5);
  return (<group position={[WX.C, 0, 0]}>
    <Water pos={[0, 0, -40]} size={[200, 200]} />
    <TreeRing r={62} n={40} />
    {[[-6, -4], [6, -4], [-6, 4], [6, 4], [0, -4], [0, 4]].map((p, i) => <Solid key={i} kind="cyl" args={[0.3, 0.34, 5.2, 8]} pos={[p[0], -0.8, p[1]]} color="#5a4030" tex={wornTex('#5a4030', 'planks', 52, [1, 2])} />)}
    <Solid kind="box" args={[14, 0.8, 10]} pos={[0, 1.2, 0]} tex={deck} color="#8a6038" />
    <Derrick pos={[0, 1.6, -2.5]} h={9} pipe={0.001} />
    <Solid kind="cyl" args={[0.14, 0.14, 12, 8]} pos={[0, 3.6 + shake, -2.5]} color="#8a8a92" />
    <Solid kind="box" args={[4, 2.4, 3]} pos={[-4.2, 2.8, -3]} tex={wornTex('#b0a58a', 'planks', 53, [2, 1])} color="#b0a58a" />
    <Solid kind="box" args={[4.6, 0.25, 3.6]} pos={[-4.2, 4.1, -3]} color="#8a3a30" />
    <Beam a={[0, 6.2, -2.5]} b={[-1.0, 2.6, 1.9]} r={0.04} color="#c9b27a" outline={false} /><Beam a={[0, 6.2, -2.5]} b={[-2.4, 2.6, 2.1]} r={0.04} color="#c9b27a" outline={false} />
    <Character kind="crew" pos={[-2.2, 1.6, 2.2]} seed={1} pose="pull" /><Character kind="crew" pos={[-0.1, 1.6, 2.0]} seed={2} pose="pull" /><Character kind="crew" pos={[2.0, 1.6, 2.4]} seed={3} pose="point" />
    <Crate pos={[4.2, 1.6, 2.9]} s={1.5} label="NOV 20, 1980" labelP={seg(t, 16.15, 16.65)} rotY={-0.15} />
    <Barrel pos={[5.4, 1.6, 0.8]} /><Barrel pos={[5.8, 1.6, 1.9]} s={0.9} />
    <Solid kind="sphere" args={[0.35, 8, 6]} pos={[-5.5, 0.15, 10]} color="#c8493f" />
    <Rowboat pos={[-7, 0, 11]} rotY={0.7} />
  </group>);
}

// ================= D: cross-section, the drill breaks through (shot 5) =================
export function WorldD() {
  const t = useT();
  const bitY = 10 + (3.3 - 10) * ease(seg(t, 20.4, 21.65));
  const hole = t >= 21.65;
  const drop = 3.2 * ease(seg(t, 22.6, 25.0));
  const lakeH = 4 - drop;
  const flood = 2.5 * ease(seg(t, 22.0, 25.1));
  const tilt = 0.14 * ease(seg(t, 23.6, 25.1));
  const stones = wornTex('#8a6a48', 'stones', 61, [3, 1]);
  const miners = t >= 22.3;
  return (<group position={[WX.D, 0, 0]}>
    <Solid kind="box" args={[38, lakeH, 10]} pos={[0, 6 + lakeH / 2, 0]} tex={wornTex("#4a93b3", "stones", 77, [3, 1])} color="#4a93b3" />
    <Water pos={[0, 6 + lakeH + 0.02, 0]} size={[38, 10]} drain={ease(seg(t, 22.9, 25.0))} center={[WX.D, 0]} segs={[60, 24]} />
    <Solid kind="box" args={[18.6, 2.6, 10]} pos={[-9.7, 4.7, 0]} tex={stones} color="#8a6a48" />
    <Solid kind="box" args={[18.6, 2.6, 10]} pos={[9.7, 4.7, 0]} tex={stones} color="#8a6a48" />
    {!hole && <Solid kind="box" args={[0.8, 2.6, 10]} pos={[0, 4.7, 0]} tex={stones} color="#8a6a48" />}
    <Solid kind="box" args={[38, 1.4, 10]} pos={[0, -0.7, 0]} tex={wornTex('#ece0d8', 'salt', 62, [4, 1])} color="#ece0d8" />
    <Solid kind="box" args={[38, 3.4, 0.6]} pos={[0, 1.7, -4.7]} tex={wornTex('#5a4a42', 'stones', 63, [4, 1])} color="#5a4a42" />
    <Solid kind="box" args={[1, 3.4, 10]} pos={[-19, 1.7, 0]} color="#5a4a42" /><Solid kind="box" args={[1, 3.4, 10]} pos={[19, 1.7, 0]} color="#5a4a42" />
    {/* rig on piles above the lake */}
    {[-5, 5].map(x => <Solid key={x} kind="cyl" args={[0.3, 0.34, 6, 8]} pos={[x, 9, 1]} color="#5a4030" />)}
    <Solid kind="box" args={[12, 0.7, 6]} pos={[0, 11.9, 0]} tex={wornTex('#8a6038', 'planks', 64, [3, 1])} color="#8a6038" />
    <Derrick pos={[0, 12.25, -1.6]} h={6} tilt={[0, 0, tilt]} pipe={0.001} />
    <Solid kind="cyl" args={[0.12, 0.12, 15 - bitY, 8]} pos={[0, (15 + bitY) / 2, 0.6]} color="#8a8a92" />
    <Solid kind="cone" args={[0.3, 0.6, 8]} pos={[0, bitY - 0.3, 0.6]} rot={[Math.PI, 0, 0]} color="#3a3a42" />
    {/* the jet of water falling through the hole and flooding the mine */}
    {hole && <Water pos={[0, 3.4, 0.6]} size={[0.9, 3.4]} flow={[0, 6]} scale={1.2} colors={['#3f86a6', '#5fa6bf', '#e8f6fa']} />}
    {hole && <mesh position={[0, 1.7, 0.6]}><boxGeometry args={[0.9, 3.4, 0.9]} /><meshToonMaterial color="#5fa6bf" gradientMap={toonMat('#fff').gradientMap} transparent opacity={0.85} /></mesh>}
    {flood > 0.01 && <Solid kind="box" args={[36, flood, 9.4]} pos={[0, flood / 2, 0.2]} color="#3f86a6" outline={false} />}
    <Character kind="miner" pos={[-6, 0, 0.9]} seed={1} pose={miners ? 'up' : 'idle'} /><Character kind="miner" pos={[6.2, 0, 0.6]} seed={2} pose={miners ? 'up' : 'point'} />
    <Lantern pos={[3.8, 2.7, 6.4]} />
  </group>);
}

// ================= E: whirlpool swallows rig, barges, tug, land (shot 6) =================
export function WorldE() {
  const t = useT();
  const drain = ease(seg(t, 25.2, 27.0)) * 0.95;
  const C = [0, -7];
  const place = (r0, a0, ts, te) => {
    const u = ease(seg(t, ts, te));
    const r = r0 * (1 - u) + 1.2 * u; const a = a0 + 0.3 * (t - 25.2) + 2.6 * u * (1 + u);
    return { x: C[0] + r * Math.cos(a), z: C[1] + r * Math.sin(a), r, a, u, y: funnelY(drain, r) };
  };
  const sinkOf = (te, k = 13) => k * ease(seg(t, te - 0.6, te + 0.9));
  const rig = place(5.6, Math.atan2(2, 5), 25.9, 27.9);
  const tug = place(13, 1.0, 27.4, 29.8);
  const bank = ease(seg(t, 29.9, 31.7)), isl = ease(seg(t, 31.4, 32.7));
  return (<group position={[WX.E, 0, 0]}>
    <Water pos={[0, 0, -30]} size={[160, 120]} drain={drain} center={[WX.E + C[0], C[1]]} segs={[220, 170]} />
    <TreeRing r={64} n={44} seed={8} />
    <group position={[rig.x, rig.y - sinkOf(27.9, 14), rig.z]} rotation={[0, 0, 0.55 * ease(seg(t, 26.3, 27.8))]}>
      <Solid kind="box" args={[10, 0.7, 7]} pos={[0, 0.6, 0]} tex={wornTex('#8a6038', 'planks', 71, [3, 1])} color="#8a6038" />
      <Derrick pos={[0, 0.9, -1]} h={8} pipe={0.001} />
    </group>
    {Array.from({ length: 11 }).map((_, i) => {
      const p = place(12 + (i % 3) * 3.6, i * (Math.PI * 2 / 11) + 0.3, 26.0 + i * 0.12, 28.9 + i * 0.1);
      return <Barge key={i} pos={[p.x, p.y + 0.15 - sinkOf(28.9 + i * 0.1), p.z]} rot={[0, -(p.a + Math.PI / 2), 0.3 * drain]} color={['#8a4a3a', '#6a7a4a', '#7a5a8a', '#4a6a8a'][i % 4]} />;
    })}
    <Tugboat pos={[tug.x, tug.y + 0.2 - sinkOf(29.8), tug.z]} rot={[0, -(tug.a + Math.PI / 2), 0.35 * drain]} />
    <group position={[-16 + 5 * bank, -7 * bank, -1 - 3 * bank]} rotation={[0, 0, -0.6 * bank]}>
      <Solid kind="box" args={[14, 1.6, 9]} pos={[0, -0.6, 0]} tex={wornTex('#7c9a55', 'grass', 72, [4, 3])} color="#7c9a55" />
      <Oak pos={[-3, 0.2, 0]} s={0.8} seed={6} /><Oak pos={[3, 0.2, 1.5]} s={0.7} seed={7} />
    </group>
    <group position={[13 - 2.5 * isl, -8 * isl, -15 + 3 * isl]} rotation={[0.5 * isl, 0, 0.45 * isl]}>
      <Solid kind="cyl" args={[6, 6.6, 1.6, 14]} pos={[0, -0.5, 0]} tex={wornTex('#7c9a55', 'grass', 73, [3, 3])} color="#7c9a55" />
      <Oak pos={[0, 0.3, 0]} s={1.1} seed={9} />
    </group>
    <Reeds pos={[-9, 0, 9.5]} n={11} s={1.6} seed={11} />
  </group>);
}

// ================= F: the canal runs backward (shot 7) =================
export function flowOffset(t) {
  let o = 0; const dt = 1 / 30;
  for (let s = 32.8; s < t; s += dt) { const k = clamp01((s - 35.3) / 0.8); o += (2.2 * (1 - k) + (-3.4) * k) * dt; }
  return o;
}
export function WorldF() {
  const t = useT();
  const off = flowOffset(t);
  const arrowP = ease(seg(t, 36.25, 37.05));
  const gulfP = seg(t, 37.4, 38.0);
  return (<group position={[WX.F, 0, 0]}>
    <Water pos={[0, -0.5, 0]} size={[200, 5.2]} flow={[off / Math.max(t, 0.01), 0]} scale={0.7} />
    <Water pos={[-80, -0.5, 0]} size={[120, 130]} scale={0.4} />
    <Water pos={[90, -0.5, 0]} size={[100, 130]} scale={0.4} />
    <Ground size={[200, 60]} pos={[20, -0.48, 32.6]} /><Ground size={[200, 60]} pos={[20, -0.48, -32.6]} />
    <TreeRing r={62} n={34} seed={12} />
    <PostSign text="DELCAMBRE CANAL" pos={[0, 0, 3.7]} w={7.2} h={1.7} postH={4.4} />
    {/* the arrow is drawn on a board while the narrator says "backward" */}
    <group position={[-6.2, 0, 3.8]}>
      <Solid kind="box" args={[0.3, 3.6, 0.3]} pos={[-2.4, 1.8, 0]} color="#7a5a3a" /><Solid kind="box" args={[0.3, 3.6, 0.3]} pos={[2.4, 1.8, 0]} color="#7a5a3a" />
      <Solid kind="box" args={[5.4, 2.0, 0.2]} pos={[0, 2.6, 0]} tex={wornTex('#e9d9b0', 'planks', 81, [2, 1])} color="#e9d9b0" />
      {arrowP > 0.01 && <Solid kind="box" args={[3.8 * arrowP, 0.28, 0.1]} pos={[1.9 - 1.9 * arrowP, 2.6, 0.16]} color="#b03a3a" outline={false} />}
      {arrowP > 0.9 && <Solid kind="cone" args={[0.55, 0.9, 3]} pos={[-1.9 - 0.2, 2.6, 0.16]} rot={[0, 0, Math.PI / 2]} color="#b03a3a" outline={false} />}
    </group>
    <Banner text="FROM THE GULF" pos={[-17.5, 0, 3.6]} w={5} h={1.2} poleH={3.6} progress={gulfP} />
    <Barge pos={[6 + off, -0.15, 0]} rot={[0, 0, 0]} color="#7a4a3a" />
    <Character kind="fisher" pos={[-10, 0, 4]} seed={2} pose="point" />
    <Reeds pos={[0.2, 0, 6.2]} n={9} s={1.1} seed={15} /><Reeds pos={[14, 0, 3]} n={9} seed={16} /><Oak pos={[8, 0, 12]} s={1.4} seed={13} />
  </group>);
}

// ================= G: the lake refills, nine barges float back up (shot 8) =================
function Dashed({ pos, w = 4.4, d = 2 }) {
  const tex = useMemo(() => {
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 128; const g = cv.getContext('2d');
    g.strokeStyle = '#b03a3a'; g.lineWidth = 8; g.setLineDash([22, 14]); g.strokeRect(8, 8, 240, 112);
    const tx = new THREE.CanvasTexture(cv); tx.colorSpace = THREE.SRGBColorSpace; return tx;
  }, []);
  return <mesh position={pos} rotation={[-Math.PI / 2, 0, 0]} renderOrder={3}><planeGeometry args={[w, d]} /><meshBasicMaterial map={tex} transparent toneMapped={false} depthWrite={false} /></mesh>;
}
const G_BARGES = [[-18, -4], [-12, -12], [-4, -4], [4, -14], [8, -2], [16, -9], [-16, -20], [0, -24], [14, -20], [-6, -15], [12, -9]];
export function WorldG() {
  const t = useT();
  const waterY = -4.7 + 4.4 * ease(seg(t, 38.5, 40.6));
  const mud = wornTex('#6a5a48', 'stones', 91, [10, 8]);
  return (<group position={[WX.G, 0, 0]}>
    <Solid kind="box" args={[140, 1, 140]} pos={[0, -5.5, -10]} tex={mud} color="#6a5a48" outline={false} />
    <Solid kind="box" args={[60, 5, 140]} pos={[-58, -2.5, -10]} tex={wornTex('#7c9a55', 'grass', 92, [8, 8])} color="#7c9a55" outline={false} />
    <Solid kind="box" args={[60, 5, 140]} pos={[58, -2.5, -10]} tex={wornTex('#7c9a55', 'grass', 92, [8, 8])} color="#7c9a55" outline={false} />
    <Solid kind="box" args={[60, 5, 60]} pos={[0, -2.5, -70]} tex={wornTex('#7c9a55', 'grass', 92, [8, 8])} color="#7c9a55" outline={false} />
    <Solid kind="box" args={[60, 5, 60]} pos={[0, -2.5, 42]} tex={wornTex('#7c9a55', 'grass', 92, [8, 8])} color="#7c9a55" outline={false} />
    <Water pos={[0, waterY, -9]} size={[57, 43]} scale={0.5} />
    <TreeRing r={60} n={34} seed={21} y={0} />
    {G_BARGES.map((p, i) => {
      const missing = i >= 9;
      const pop = backOut(seg(t, 40.7 + 0.22 * i, 41.45 + 0.22 * i));
      const y = -4.55 + (-0.1 + 0.2 + 4.55) * pop;
      return (<group key={i}>
        {!missing && <Barge pos={[p[0], y + (pop > 0.98 ? Math.sin(t * 1.6 + i) * 0.05 : 0), p[1]]} rot={[0.18 * (1 - pop), (i * 0.7) % 3, 0.12 * (1 - pop)]} color={['#8a4a3a', '#6a7a4a', '#7a5a8a', '#4a6a8a'][i % 4]} />}
        {missing && t > 41.3 && <Dashed pos={[p[0], -0.28, p[1]]} />}
      </group>);
    })}
    <Banner text="TWO DAYS" pos={[-4, 0, 8.5]} w={4.4} h={1.2} poleH={4} progress={seg(t, 38.7, 39.4)} />
    <Reeds pos={[-10, 0, 10.5]} n={12} s={1.5} seed={23} />
  </group>);
}

// ================= H: the new deepest lake (shots 9 and 11) =================
export function WorldH() {
  const t = useT();
  const u = ease(seg(t, 44.7, 46.2));
  const cols = [0, 1, 2].map(i => lerpCol(FRESH[i], SALT[i], u));
  const sink = 9.5 * ease(seg(t, 44.8, 47.0));
  const bannerP = seg(t, 46.9, 47.8);
  const bands = [0, 1, 2, 3, 4, 5];
  return (<group position={[WX.H, 0, 0]}>
    <Water pos={[0, 0, -43]} size={[180, 94]} colors={cols} />
    <Ground size={[180, 80]} pos={[0, -0.48, 43.5]} />
    <TreeRing r={60} n={34} arc={[Math.PI, Math.PI * 2]} seed={31} />
    <group position={[0, -sink, -3]}>
      <Solid kind="box" args={[0.34, 6.6, 0.34]} pos={[0, 3.0, 0]} color="#cbb890" />
      {bands.map(i => <Solid key={i} kind="box" args={[0.38, 0.5, 0.38]} pos={[0, 0.6 + i * 1.0, 0]} color={i % 2 ? '#b03a3a' : '#f0e6cf'} />)}
      <Solid kind="box" args={[2.6, 1.0, 0.2]} pos={[0, 6.7, 0]} tex={wornTex('#e9d9b0', 'planks', 94, [1, 1])} color="#e9d9b0" />
      <Label text="10 FT" w={2.3} h={0.8} pos={[0, 6.7, 0.115]} tw={512} th={192} font='bold 120px Georgia, "DejaVu Serif", serif' />
    </group>
    {t < 50 && <Banner text="" lines={['DEEPEST LAKE', 'IN LOUISIANA']} th={384} pos={[0, 0, 2.4]} w={7} h={2.0} poleH={5.2} progress={bannerP} />}
    <Dock pos={[8.5, 0, -0.7]} len={10} />
    <Barrel pos={[9.2, 0.68, 2.4]} s={0.8} />
    <Solid kind="cyl" args={[0.5, 0.5, 0.18, 12]} pos={[7.6, 0.8, -2.5]} color="#b79a62" />
    <Rowboat pos={[12.6, Math.sin(t * 1.2) * 0.05, -2]} rotY={0.2} color="#7a8a6a" />
    <Oak pos={[16, 0, 8]} s={1.3} seed={32} /><Oak pos={[-14, 0, 12]} s={1.5} seed={34} />
    <Reeds pos={[-5.6, 0, 7.2]} n={11} s={1.3} seed={35} /><Reeds pos={[4.8, 0, 6.2]} n={9} seed={37} />
  </group>);
}

// ================= I: the settlement office (shot 10) =================
export function WorldI() {
  const t = useT();
  const ledP = seg(t, 49.4, 49.95);
  const wall = wornTex('#b8a47a', 'plain', 101, [1, 1]);
  const floor = wornTex('#8a6038', 'planks', 102, [6, 4]);
  const desk = wornTex('#7a4e2e', 'planks', 103, [3, 1]);
  return (<group position={[WX.I, 0, 0]}>
    <Solid kind="box" args={[34, 0.4, 26]} pos={[0, -0.2, -2]} tex={floor} color="#8a6038" outline={false} />
    <Solid kind="wall" args={[34, 10, 0.6, [{ x: -7, y: 3, w: 5.4, h: 4.2 }, { x: 7, y: 3, w: 5.4, h: 4.2 }]]} pos={[0, 0, -7]} tex={wall} color="#b8a47a" />
    <mesh position={[0, 5, -7.6]}><planeGeometry args={[40, 14]} /><meshBasicMaterial map={skyTex('#9fc9d8', '#f2e3c6', 9)} fog={false} toneMapped={false} /></mesh>
    <Solid kind="box" args={[0.6, 10, 26]} pos={[-17, 5, -2]} tex={wall} color="#b8a47a" /><Solid kind="box" args={[0.6, 10, 26]} pos={[17, 5, -2]} tex={wall} color="#b8a47a" />
    <Solid kind="box" args={[34, 2.2, 0.3]} pos={[0, 1.1, -6.6]} tex={wornTex('#7a5a3a', 'planks', 104, [4, 1])} color="#7a5a3a" />
    {/* desk with nameplate */}
    <Solid kind="box" args={[6.6, 0.32, 1.8]} pos={[0, 2.0, 0]} tex={desk} color="#7a4e2e" />
    <Solid kind="box" args={[6.2, 1.85, 0.18]} pos={[0, 0.92, 0.8]} tex={desk} color="#6a4228" />
    <Solid kind="box" args={[0.4, 1.85, 1.6]} pos={[-3.0, 0.92, 0]} tex={desk} color="#6a4228" /><Solid kind="box" args={[0.4, 1.85, 1.6]} pos={[3.0, 0.92, 0]} tex={desk} color="#6a4228" />
    <Label text="" lines={['DIAMOND CRYSTAL', 'SALT CO.']} w={3.7} h={1.0} pos={[0, 1.05, 0.92]} bg="#cfae58" th={256} font='bold 96px Georgia, "DejaVu Serif", serif' />
    <Character kind="boss" pos={[0, 0.95, -1.7]} seed={1} sit pose="idle" />
    <Character kind="clerk" pos={[-4.8, 0, 0.8]} seed={2} pose="point" />
    {/* ledger tilted toward the camera */}
    <group position={[1.6, 2.28, 0.05]} rotation={[0.95, 0, 0]}>
      <Solid kind="box" args={[2.0, 0.14, 1.3]} color="#e9d9b0" />
      <group scale={[ease(ledP), ease(ledP), 1]}><Label text="" lines={['SETTLED', '$32,000,000']} w={1.8} h={1.1} pos={[0, 0.09, 0]} rot={[-Math.PI / 2, 0, 0]} tw={512} th={320} font='bold 96px Georgia, "DejaVu Serif", serif' /></group>
    </group>
    {[0, 1, 2].map(i => <Solid key={i} kind="cyl" args={[0.3, 0.3, 0.08, 12]} pos={[-1.8, 2.2 + i * 0.09, 0.2]} color="#d9b24a" />)}
    <Solid kind="cyl" args={[0.5, 0.4, 0.9, 10]} pos={[-6.4, 0.45, 6.2]} color="#a86a3f" /><Solid kind="sphere" args={[0.9, 10, 8]} pos={[-6.4, 1.5, 6.2]} color="#5d8a4a" />
    <Solid kind="cyl" args={[0.2, 0.3, 0.5, 8]} pos={[2.8, 2.4, -0.4]} color="#2f6a58" /><Solid kind="cone" args={[0.55, 0.5, 8]} pos={[2.8, 2.9, -0.4]} color="#2f6a58" />
  </group>);
}
