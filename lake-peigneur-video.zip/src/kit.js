import * as THREE from 'three';
import { mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

export const INK = '#351f22';
export const CREAM = '#f4e8d2';

// ---------- seeded random ----------
export function rng(seed) {
  let s = Math.floor(seed * 9301 + 49297) % 233280 || 1;
  return () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
}

// ---------- 3-band toon gradient ----------
export const toonGradient = (() => {
  const t = new THREE.DataTexture(new Uint8Array([105, 185, 255]), 3, 1, THREE.RedFormat);
  t.minFilter = THREE.NearestFilter; t.magFilter = THREE.NearestFilter; t.needsUpdate = true;
  return t;
})();

// ---------- painted flat-colour textures with wear ----------
const texCache = new Map();
function shade(hex, f) {
  const c = new THREE.Color(hex); c.multiplyScalar(f); return '#' + c.getHexString();
}
export function wornTex(base, pattern = 'plain', seed = 1, repeat = [1, 1]) {
  const key = [base, pattern, seed, repeat.join('x')].join('|');
  if (texCache.has(key)) return texCache.get(key);
  const W = 256, H = 256;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const g = cv.getContext('2d'); const R = rng(seed);
  g.fillStyle = base; g.fillRect(0, 0, W, H);
  if (pattern === 'planks') {
    const n = 6;
    for (let i = 0; i < n; i++) {
      g.fillStyle = shade(base, 0.88 + R() * 0.22); g.fillRect(0, i * H / n, W, H / n - 3);
      g.fillStyle = shade(base, 0.6); g.fillRect(0, (i + 1) * H / n - 3, W, 3);
      g.strokeStyle = shade(base, 0.8); g.lineWidth = 1.5;
      for (let k = 0; k < 3; k++) { const y = i * H / n + 6 + R() * (H / n - 14); g.beginPath(); g.moveTo(R() * 60, y); g.lineTo(120 + R() * 130, y + (R() - .5) * 3); g.stroke(); }
      g.fillStyle = shade(base, 0.55); const nx = 20 + R() * 216; g.beginPath(); g.arc(nx, i * H / n + H / n / 2, 2.2, 0, 7); g.fill();
    }
  } else if (pattern === 'bricks') {
    const rows = 8, cols = 4;
    g.fillStyle = shade(base, 0.62); g.fillRect(0, 0, W, H);
    for (let r = 0; r < rows; r++) for (let c = -1; c < cols; c++) {
      const off = (r % 2) * (W / cols / 2);
      g.fillStyle = shade(base, 0.86 + R() * 0.3);
      g.fillRect(c * W / cols + off + 2, r * H / rows + 2, W / cols - 4, H / rows - 4);
    }
  } else if (pattern === 'stones') {
    for (let i = 0; i < 26; i++) { g.fillStyle = shade(base, 0.8 + R() * 0.4); g.beginPath(); g.ellipse(R() * W, R() * H, 20 + R() * 28, 14 + R() * 20, R() * 3, 0, 7); g.fill(); }
  } else if (pattern === 'grass') {
    for (let i = 0; i < 220; i++) { g.strokeStyle = shade(base, 0.7 + R() * 0.55); g.lineWidth = 2; const x = R() * W, y = R() * H; g.beginPath(); g.moveTo(x, y); g.lineTo(x + (R() - .5) * 8, y - 6 - R() * 8); g.stroke(); }
  } else if (pattern === 'salt') {
    for (let i = 0; i < 90; i++) { g.fillStyle = shade(base, 0.9 + R() * 0.16); const s = 6 + R() * 26; g.fillRect(R() * W, R() * H, s, s * (0.5 + R())); }
  }
  // wear: stains, chips, scratches
  for (let i = 0; i < 7; i++) { g.fillStyle = `rgba(40,25,20,${0.04 + R() * 0.07})`; g.beginPath(); g.arc(R() * W, R() * H, 10 + R() * 34, 0, 7); g.fill(); }
  for (let i = 0; i < 14; i++) { g.fillStyle = shade(base, 1.25); g.fillRect(R() * W, R() * H, 2 + R() * 6, 2 + R() * 3); }
  g.strokeStyle = 'rgba(30,20,18,0.28)'; g.lineWidth = 1;
  for (let i = 0; i < 9; i++) { const x = R() * W, y = R() * H; g.beginPath(); g.moveTo(x, y); g.lineTo(x + (R() - .5) * 50, y + (R() - .5) * 20); g.stroke(); }
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]);
  t.anisotropy = 4;
  texCache.set(key, t); return t;
}

// ---------- painted sign texture (labels live inside the world) ----------
const signCache = new Map();
export function signTex(text, { bg = '#e9d9b0', fg = '#3a2418', w = 1024, h = 256, font = 'bold 120px Georgia, "DejaVu Serif", serif', border = true, lines = null } = {}) {
  const key = text + bg + fg + w + h + font;
  if (signCache.has(key)) return signCache.get(key);
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const g = cv.getContext('2d'); const R = rng(text.length * 7 + 3);
  g.fillStyle = bg; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 40; i++) { g.fillStyle = `rgba(60,40,25,${0.03 + R() * 0.05})`; g.beginPath(); g.arc(R() * w, R() * h, 8 + R() * 40, 0, 7); g.fill(); }
  if (border) { g.strokeStyle = fg; g.lineWidth = 8; g.strokeRect(16, 16, w - 32, h - 32); }
  g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle';
  const arr = lines || [text];
  g.font = font;
  // shrink to fit
  let size = parseInt(font.match(/(\d+)px/)[1], 10);
  const widest = () => Math.max(...arr.map(l => g.measureText(l).width));
  while (widest() > w - 90 && size > 20) { size -= 4; g.font = font.replace(/\d+px/, size + 'px'); }
  arr.forEach((l, i) => g.fillText(l, w / 2 + (R() - .5) * 3, h / 2 + (i - (arr.length - 1) / 2) * size * 1.12 + (R() - .5) * 2));
  for (let i = 0; i < 12; i++) { g.fillStyle = `rgba(233,217,176,${0.4 + R() * 0.3})`; g.fillRect(R() * w, R() * h, 3 + R() * 8, 2 + R() * 3); }
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  signCache.set(key, t); return t;
}

// ---------- toon material cache ----------
const matCache = new Map();
export function toonMat(color, map = null, extra = {}) {
  const key = color + '|' + (map ? map.uuid : '') + JSON.stringify(extra);
  if (matCache.has(key)) return matCache.get(key);
  const m = new THREE.MeshToonMaterial({ color, map, gradientMap: toonGradient, ...extra });
  matCache.set(key, m); return m;
}

// ---------- ink outline (inverted hull whose thickness follows camera distance) ----------
const hullMat = new THREE.ShaderMaterial({
  side: THREE.BackSide,
  uniforms: { uColor: { value: new THREE.Color(INK) }, uK: { value: 0.0026 } },
  vertexShader: `
    uniform float uK;
    void main(){
      vec4 wp = modelMatrix * vec4(position,1.0);
      vec3 n = normalize(mat3(modelMatrix) * normal);
      float d = distance(cameraPosition, wp.xyz);
      wp.xyz += n * uK * d;
      gl_Position = projectionMatrix * viewMatrix * wp;
    }`,
  fragmentShader: `uniform vec3 uColor; void main(){ gl_FragColor = vec4(uColor,1.0); }`,
});
export function makeHull(geo) {
  let g = geo.clone();
  ['normal', 'uv', 'uv1', 'color'].forEach(a => g.deleteAttribute(a));
  g = mergeVertices(g, 1e-3); g.computeVertexNormals();
  return g;
}
export { hullMat };

// geometry helpers
export const boxGeo = (w, h, d) => new THREE.BoxGeometry(w, h, d);
export function archGeo(w, h, depth, segs = 14) {
  // brick vault / tunnel cross-section: rectangle with half-round top, extruded along z
  const s = new THREE.Shape();
  const r = w / 2;
  s.moveTo(-r, 0); s.lineTo(-r, h - r);
  s.absarc(0, h - r, r, Math.PI, 0, true);
  s.lineTo(r, 0); s.lineTo(-r, 0);
  const hole = new THREE.Path();
  const t = 0.35;
  hole.moveTo(-r + t, 0); hole.lineTo(r - t, 0); hole.lineTo(r - t, h - r);
  hole.absarc(0, h - r, r - t, 0, Math.PI, false); hole.lineTo(-r + t, 0);
  s.holes.push(hole);
  const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: false, curveSegments: segs });
  g.translate(0, 0, -depth / 2);
  return g;
}
export function wallWithOpenings(w, h, d, openings = []) {
  // extruded wall with window / door notches (door notches open to the bottom edge)
  const s = new THREE.Shape();
  s.moveTo(-w / 2, 0); s.lineTo(w / 2, 0); s.lineTo(w / 2, h); s.lineTo(-w / 2, h); s.lineTo(-w / 2, 0);
  openings.forEach(o => {
    const p = new THREE.Path();
    p.moveTo(o.x - o.w / 2, o.y); p.lineTo(o.x - o.w / 2, o.y + o.h); p.lineTo(o.x + o.w / 2, o.y + o.h); p.lineTo(o.x + o.w / 2, o.y); p.lineTo(o.x - o.w / 2, o.y);
    s.holes.push(p);
  });
  const g = new THREE.ExtrudeGeometry(s, { depth: d, bevelEnabled: false });
  g.translate(0, 0, -d / 2);
  return g;
}
// sky dome texture: warm cream to pale blue with painted cloud blobs
export function skyTex(top = '#9fc9d8', bottom = '#f2e3c6', seed = 3) {
  const key = 'sky' + top + bottom + seed;
  if (texCache.has(key)) return texCache.get(key);
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 512;
  const g = cv.getContext('2d'); const R = rng(seed);
  const grad = g.createLinearGradient(0, 0, 0, 512); grad.addColorStop(0, top); grad.addColorStop(0.62, bottom); grad.addColorStop(1, bottom);
  g.fillStyle = grad; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 9; i++) {
    const x = R() * 512, y = 90 + R() * 160; g.fillStyle = 'rgba(255,248,232,0.85)';
    for (let k = 0; k < 5; k++) { g.beginPath(); g.ellipse(x + k * 22 - 44, y + (R() - .5) * 10, 26 + R() * 18, 14 + R() * 8, 0, 0, 7); g.fill(); }
  }
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace;
  texCache.set(key, t); return t;
}

// ---------- water shader: painted ripple bands, optional whirlpool funnel and flow ----------
export function makeWaterMaterial(c1 = '#3f86a6', c2 = '#5fa6bf', c3 = '#9bd0dc') {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0 }, uC1: { value: new THREE.Color(c1) }, uC2: { value: new THREE.Color(c2) }, uC3: { value: new THREE.Color(c3) },
      uDrain: { value: 0 }, uCenter: { value: new THREE.Vector2(0, 0) }, uFlow: { value: new THREE.Vector2(0, 0) }, uScale: { value: 0.5 },
    },
    vertexShader: `
      uniform float uDrain; uniform vec2 uCenter;
      varying vec3 vW;
      void main(){
        vec3 p = position;
        vec4 wp = modelMatrix * vec4(p,1.0);
        vec2 q = wp.xz - uCenter;
        float r = length(q);
        float funnel = uDrain * (1.0 - smoothstep(0.0, 11.0, r));
        wp.y -= funnel * funnel * 4.2 + funnel * 0.6;
        vW = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }`,
    fragmentShader: `
      uniform float uTime; uniform vec3 uC1; uniform vec3 uC2; uniform vec3 uC3;
      uniform float uDrain; uniform vec2 uCenter; uniform vec2 uFlow; uniform float uScale;
      varying vec3 vW;
      void main(){
        vec2 p = (vW.xz - uFlow * uTime) * uScale;
        float w = sin(p.x*2.1 + uTime*0.9) * sin(p.y*1.7 - uTime*0.7) + 0.5*sin((p.x+p.y)*3.3 + uTime*1.3);
        vec2 q = vW.xz - uCenter; float r = length(q); float a = atan(q.y, q.x);
        float spiral = sin(a*5.0 + r*1.6 - uTime*6.0*uDrain);
        float inF = uDrain * (1.0 - smoothstep(0.0, 11.0, r));
        w = mix(w, spiral*1.4, clamp(inF*1.4,0.0,1.0));
        vec3 col = uC1;
        if (w > -0.2) col = uC2;
        if (w > 0.75) col = uC3;
        col *= 1.0 - 0.45*inF*(1.0 - smoothstep(0.0, 5.0, r)) ;
        gl_FragColor = vec4(col, 1.0);
      }`,
  });
}
