import React, { useMemo } from 'react';
import * as THREE from 'three';
import { useCurrentFrame } from 'remotion';
import { INK, rng } from './kit.js';
import { camAt } from './camera.js';

const SKIN = '#f3dfc4';
const texCache = new Map();

function wobbleStroke(g, drawPath, width, R, passes = 3) {
  // hand-drawn ink band: several slightly offset strokes of varying thickness
  for (let i = 0; i < passes; i++) {
    g.save();
    g.translate((R() - .5) * 2.2, (R() - .5) * 2.2);
    g.lineWidth = width * (0.7 + R() * 0.6); g.strokeStyle = INK; g.lineJoin = 'round'; g.lineCap = 'round';
    drawPath(); g.stroke(); g.restore();
  }
}
function mk(w, h, fn, key) {
  if (texCache.has(key)) return texCache.get(key);
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const g = cv.getContext('2d'); fn(g, rng(key.length * 13 + w));
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  texCache.set(key, t); return t;
}

function headTex(v) {
  return mk(256, 256, (g, R) => {
    // hair behind
    const cx = 128, cy = 132, r = 96;
    g.fillStyle = SKIN; g.beginPath(); g.arc(cx, cy, r, 0, 7); g.fill();
    wobbleStroke(g, () => { g.beginPath(); g.arc(cx, cy, r, 0, 7); }, 7, R);
    // hair fringe
    if (v.hat !== 'tophat' && v.hat !== 'bowler') {
      g.fillStyle = v.hair;
      g.beginPath(); g.moveTo(cx - 92, cy - 24); g.quadraticCurveTo(cx - 60, cy - 120, cx + 10, cy - 100);
      g.quadraticCurveTo(cx + 80, cy - 100, cx + 92, cy - 22); g.quadraticCurveTo(cx + 40, cy - 62, cx - 6, cy - 50); g.quadraticCurveTo(cx - 50, cy - 40, cx - 92, cy - 24); g.fill();
      wobbleStroke(g, () => { g.beginPath(); g.moveTo(cx - 92, cy - 24); g.quadraticCurveTo(cx - 60, cy - 120, cx + 10, cy - 100); g.quadraticCurveTo(cx + 80, cy - 100, cx + 92, cy - 22); g.quadraticCurveTo(cx + 40, cy - 62, cx - 6, cy - 50); g.quadraticCurveTo(cx - 50, cy - 40, cx - 92, cy - 24); }, 5, R, 2);
    } else {
      g.fillStyle = v.hair; g.fillRect(cx - 94, cy - 30, 14, 40); g.fillRect(cx + 80, cy - 30, 14, 40);
    }
    // half-lidded eyes
    [-36, 36].forEach(dx => {
      g.fillStyle = '#2b1b1e'; g.beginPath(); g.ellipse(cx + dx, cy + 8, 11, 11, 0, 0, 7); g.fill();
      g.fillStyle = SKIN; g.fillRect(cx + dx - 16, cy - 6, 32, 11);
      wobbleStroke(g, () => { g.beginPath(); g.moveTo(cx + dx - 16, cy + 5); g.lineTo(cx + dx + 16, cy + 5); }, 4, R, 2);
    });
    // tiny smile
    wobbleStroke(g, () => { g.beginPath(); g.arc(cx, cy + 38, 17, 0.25, Math.PI - 0.25); }, 4, R, 2);
    // glasses
    if (v.glasses) {
      wobbleStroke(g, () => { g.beginPath(); g.arc(cx - 36, cy + 8, 22, 0, 7); g.moveTo(cx + 58, cy + 8); g.arc(cx + 36, cy + 8, 22, 0, 7); g.moveTo(cx - 14, cy + 8); g.lineTo(cx + 14, cy + 8); }, 4, R, 2);
    }
    // hats
    if (v.hat === 'tophat') {
      g.fillStyle = v.hatColor; g.fillRect(cx - 52, cy - 168, 104, 100);
      wobbleStroke(g, () => { g.beginPath(); g.rect(cx - 52, cy - 168, 104, 100); }, 6, R, 2);
      g.fillStyle = v.hatColor; g.beginPath(); g.ellipse(cx, cy - 66, 100, 14, 0, 0, 7); g.fill();
      wobbleStroke(g, () => { g.beginPath(); g.ellipse(cx, cy - 66, 100, 14, 0, 0, 7); }, 6, R, 2);
      g.fillStyle = '#a63a3a'; g.fillRect(cx - 52, cy - 96, 104, 12);
    } else if (v.hat === 'bowler') {
      g.fillStyle = v.hatColor; g.beginPath(); g.moveTo(cx - 70, cy - 66); g.quadraticCurveTo(cx - 70, cy - 150, cx, cy - 150); g.quadraticCurveTo(cx + 70, cy - 150, cx + 70, cy - 66); g.closePath(); g.fill();
      wobbleStroke(g, () => { g.beginPath(); g.moveTo(cx - 70, cy - 66); g.quadraticCurveTo(cx - 70, cy - 150, cx, cy - 150); g.quadraticCurveTo(cx + 70, cy - 150, cx + 70, cy - 66); g.closePath(); }, 6, R, 2);
      g.fillStyle = v.hatColor; g.beginPath(); g.ellipse(cx, cy - 66, 98, 13, 0, 0, 7); g.fill();
      wobbleStroke(g, () => { g.beginPath(); g.ellipse(cx, cy - 66, 98, 13, 0, 0, 7); }, 6, R, 2);
    } else if (v.hat === 'cap') {
      g.fillStyle = v.hatColor; g.beginPath(); g.moveTo(cx - 86, cy - 44); g.quadraticCurveTo(cx - 80, cy - 140, cx + 6, cy - 134); g.quadraticCurveTo(cx + 84, cy - 130, cx + 90, cy - 44); g.closePath(); g.fill();
      wobbleStroke(g, () => { g.beginPath(); g.moveTo(cx - 86, cy - 44); g.quadraticCurveTo(cx - 80, cy - 140, cx + 6, cy - 134); g.quadraticCurveTo(cx + 84, cy - 130, cx + 90, cy - 44); g.closePath(); }, 6, R, 2);
      g.fillStyle = shadeHex(v.hatColor, 0.8); g.beginPath(); g.moveTo(cx + 10, cy - 52); g.quadraticCurveTo(cx + 90, cy - 66, cx + 118, cy - 40); g.lineTo(cx + 20, cy - 36); g.closePath(); g.fill();
      wobbleStroke(g, () => { g.beginPath(); g.moveTo(cx + 10, cy - 52); g.quadraticCurveTo(cx + 90, cy - 66, cx + 118, cy - 40); g.lineTo(cx + 20, cy - 36); g.closePath(); }, 5, R, 2);
    }
  }, 'head' + JSON.stringify(v));
}
function shadeHex(hex, f) { const c = new THREE.Color(hex); c.multiplyScalar(f); return '#' + c.getHexString(); }

function torsoTex(v) {
  return mk(256, 256, (g, R) => {
    const top = 20, bot = 244, cx = 128;
    // pear-shaped body: narrow shoulders, wide base
    const path = () => { g.beginPath(); g.moveTo(cx - 52, top + 6); g.quadraticCurveTo(cx, top - 8, cx + 52, top + 6); g.quadraticCurveTo(cx + 78, top + 90, cx + 100, bot - 30); g.quadraticCurveTo(cx + 96, bot, cx + 60, bot); g.lineTo(cx - 60, bot); g.quadraticCurveTo(cx - 96, bot, cx - 100, bot - 30); g.quadraticCurveTo(cx - 78, top + 90, cx - 52, top + 6); g.closePath(); };
    g.fillStyle = v.top; path(); g.fill();
    g.save(); path(); g.clip(); g.fillStyle = v.bottom; g.fillRect(0, 150, 256, 110); g.restore();
    wobbleStroke(g, path, 7, R);
    // pocket patch
    g.fillStyle = shadeHex(v.top, 0.8); g.fillRect(cx + 22, 96, 38, 34);
    wobbleStroke(g, () => { g.beginPath(); g.rect(cx + 22, 96, 38, 34); }, 4, R, 2);
    // collar + tie
    g.fillStyle = '#fbf6ea';
    g.beginPath(); g.moveTo(cx - 6, top + 4); g.lineTo(cx - 40, top + 8); g.lineTo(cx - 14, top + 42); g.closePath(); g.fill();
    g.beginPath(); g.moveTo(cx + 6, top + 4); g.lineTo(cx + 40, top + 8); g.lineTo(cx + 14, top + 42); g.closePath(); g.fill();
    wobbleStroke(g, () => { g.beginPath(); g.moveTo(cx - 6, top + 4); g.lineTo(cx - 40, top + 8); g.lineTo(cx - 14, top + 42); g.closePath(); g.moveTo(cx + 6, top + 4); g.lineTo(cx + 40, top + 8); g.lineTo(cx + 14, top + 42); g.closePath(); }, 4, R, 2);
    g.fillStyle = v.tie; g.beginPath(); g.moveTo(cx - 8, top + 26); g.lineTo(cx + 8, top + 26); g.lineTo(cx + 12, top + 100); g.lineTo(cx, top + 116); g.lineTo(cx - 12, top + 100); g.closePath(); g.fill();
    wobbleStroke(g, () => { g.beginPath(); g.moveTo(cx - 8, top + 26); g.lineTo(cx + 8, top + 26); g.lineTo(cx + 12, top + 100); g.lineTo(cx, top + 116); g.lineTo(cx - 12, top + 100); g.closePath(); }, 4, R, 2);
  }, 'torso' + JSON.stringify(v));
}
function limbTex(kind, v) {
  // thin tapered stick limb; arms end in a dark disc hand, legs in a shoe
  return mk(64, 256, (g, R) => {
    const col = kind === 'arm' ? v.top : v.bottom;
    const path = () => { g.beginPath(); g.moveTo(24, 6); g.lineTo(40, 6); g.lineTo(37, 220); g.lineTo(27, 220); g.closePath(); };
    g.fillStyle = col; path(); g.fill(); wobbleStroke(g, path, 5, R, 2);
    g.fillStyle = '#2b1b1e';
    if (kind === 'arm') { g.beginPath(); g.arc(32, 232, 15, 0, 7); g.fill(); }
    else { g.beginPath(); g.ellipse(36, 238, 22, 11, 0, 0, 7); g.fill(); }
  }, 'limb' + kind + JSON.stringify(v));
}
function blobTex() {
  return mk(128, 128, (g) => {
    const gr = g.createRadialGradient(64, 64, 4, 64, 64, 62); gr.addColorStop(0, 'rgba(40,25,20,0.42)'); gr.addColorStop(1, 'rgba(40,25,20,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  }, 'blob');
}

const PALETTES = {
  miner: { top: '#5f7fa0', bottom: '#4a4a52', tie: '#a63a3a', hair: '#4a3328', hat: 'cap', hatColor: '#d9a83a' },
  crew: { top: '#c9803f', bottom: '#4f5a66', tie: '#2f4a6e', hair: '#2e2420', hat: 'cap', hatColor: '#e3d3a0' },
  boss: { top: '#3d4a5e', bottom: '#2c2f3a', tie: '#b03a3a', hair: '#5a4a3a', hat: 'tophat', hatColor: '#2c2528', glasses: true },
  fisher: { top: '#6a8f6a', bottom: '#6b5a44', tie: '#7a3b2e', hair: '#6a5646', hat: 'bowler', hatColor: '#7a5a3a' },
  clerk: { top: '#8a5a7a', bottom: '#46404a', tie: '#2f6a58', hair: '#352a2a', hat: 'none', glasses: true },
};
export function Character({ kind = 'miner', pos = [0, 0, 0], scale = 1, face = 0, pose = 'idle', seed = 0, sit = false, armA = null, armB = null, lean = 0 }) {
  const frame = useCurrentFrame();
  const v = PALETTES[kind];
  const mats = useMemo(() => {
    const bm = (t) => new THREE.MeshBasicMaterial({ map: t, transparent: true, alphaTest: 0.04, side: THREE.DoubleSide, toneMapped: false });
    return { head: bm(headTex(v)), torso: bm(torsoTex(v)), arm: bm(limbTex('arm', v)), leg: bm(limbTex('leg', v)),
      blob: new THREE.MeshBasicMaterial({ map: blobTex(), transparent: true, depthWrite: false }) };
  }, [kind]);
  const t = frame / 30 + seed * 1.7;
  const bob = Math.sin(t * 2.2) * 0.035;
  const nod = Math.sin(t * 1.5) * 0.06;
  // turn toward the camera, yaw clamped so people are never edge-on
  const cam = camAt(frame).pos;
  const dx = cam[0] - pos[0], dz = cam[2] - pos[2];
  let yaw = Math.atan2(dx, dz) - face;
  yaw = Math.max(-0.7, Math.min(0.7, yaw));
  let aL = 0.14 + Math.sin(t * 1.9) * 0.07, aR = -0.14 - Math.sin(t * 1.9 + 1) * 0.07;
  if (pose === 'point') { aR = -2.2 + Math.sin(t * 3) * 0.08; }
  if (pose === 'pull') { aL = -1.0 + Math.sin(t * 4) * 0.2; aR = -1.0 + Math.sin(t * 4 + 1) * 0.2; }
  if (pose === 'wave') { aR = -2.6 + Math.sin(t * 7) * 0.35; }
  if (pose === 'up') { aL = 2.5; aR = -2.5; }
  if (armA !== null) aL = armA; if (armB !== null) aR = armB;
  const legsY = sit ? 0.45 : 0, legsH = 0.85;
  return (
    <group position={pos} scale={scale} rotation={[0, face + yaw, lean]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]} material={mats.blob} renderOrder={1}><planeGeometry args={[1.5, 0.9]} /></mesh>
      <group position={[0, bob, 0]}>
        {!sit && <mesh position={[0.15, legsH / 2, 0]} material={mats.leg}><planeGeometry args={[0.2, 0.85]} /></mesh>}
        {!sit && <mesh position={[-0.15, legsH / 2, 0.001]} material={mats.leg}><planeGeometry args={[0.2, 0.85]} /></mesh>}
        <mesh position={[0, sit ? 0.95 : 1.3, 0.004]} material={mats.torso}><planeGeometry args={[1.0, 1.0]} /></mesh>
        <group position={[-0.38, sit ? 1.3 : 1.66, 0.006]} rotation={[0, 0, aL]}><mesh position={[0, -0.42, 0]} material={mats.arm}><planeGeometry args={[0.18, 0.9]} /></mesh></group>
        <group position={[0.38, sit ? 1.3 : 1.66, 0.006]} rotation={[0, 0, aR]}><mesh position={[0, -0.42, 0]} material={mats.arm}><planeGeometry args={[0.18, 0.9]} /></mesh></group>
        <group position={[0, sit ? 1.98 : 2.0, 0.008]} rotation={[0, 0, nod]}><mesh material={mats.head}><planeGeometry args={[1.05, 1.05]} /></mesh></group>
      </group>
    </group>
  );
}
