import React from 'react';
import { Composition } from 'remotion';
import { Full } from './Full.jsx';
import { TOTAL_FRAMES, FPS, W, H } from './camera.js';

export const Root = () => (
  <Composition id="LakeStory" component={Full} durationInFrames={TOTAL_FRAMES} fps={FPS} width={W} height={H} />
);
