import * as THREE from 'three';

export const FPS = 30;
export const W = 1080, H = 1920;
export const DURATION_S = 54.8;
export const TOTAL_FRAMES = Math.round(DURATION_S * FPS);

// world x offsets (each location is its own island of scenery in one scene)
export const WX = { A: 0, B: 120, C: 240, D: 360, E: 480, F: 600, G: 720, H: 840, I: 960 };

// Shot cuts come from the real sentence times of the uploaded voice-over (sentence_times.json).
// One entry per shot: start time, world, whether a cream dip happens at its start.
export const CUTS = [
  { id: 1, t0: 0.00, t1: 6.07, world: 'A' },
  { id: 2, t0: 6.07, t1: 10.93, world: 'A' },
  { id: 3, t0: 10.93, t1: 15.85, world: 'B' },
  { id: 4, t0: 15.85, t1: 20.26, world: 'C' },
  { id: 5, t0: 20.26, t1: 25.19, world: 'D' },
  { id: 6, t0: 25.19, t1: 32.80, world: 'E' },
  { id: 7, t0: 32.80, t1: 38.43, world: 'F' },
  { id: 8, t0: 38.43, t1: 43.20, world: 'G' },
  { id: 9, t0: 43.20, t1: 48.11, world: 'H' },
  { id: 10, t0: 48.11, t1: 51.71, world: 'I' },
  { id: 11, t0: 51.71, t1: 54.80, world: 'H' },
];

// Camera paths. Each group: keys with a beat time (taken from word timings), a local position and a local look-at.
// Shots 1 and 2 share one continuous path (same location).
const PATHS = [
  { from: 0.00, to: 10.93, world: 'A', keys: [
    { t: 0.00, p: [-10, 11, 26], l: [0, 2.2, -6] },
    { t: 2.00, p: [-6.5, 6.8, 19], l: [0, 2.6, -2] },
    { t: 4.90, p: [-1.5, 3.6, 11.5], l: [0, 2.9, 0] },
    { t: 6.10, p: [3.5, 3.0, 10.5], l: [7, 2.1, 0] },
    { t: 8.10, p: [10.2, 2.4, 3.2], l: [11, 1.9, -3] },
    { t: 9.40, p: [15.5, 3.0, 11.5], l: [21.5, 3.4, 3] },
    { t: 10.93, p: [19.8, 3.2, 11], l: [22, 3.7, 3] },
  ] },
  { from: 10.93, to: 15.85, world: 'B', keys: [
    { t: 10.93, p: [0, 10.5, 19], l: [0, 6.6, 0] },
    { t: 11.80, p: [-1, 5.2, 14], l: [0, 2.5, 0] },
    { t: 12.90, p: [-2.6, 2.6, 6.0], l: [-1.6, 2.0, 0] },
    { t: 14.30, p: [-8.0, 2.8, 8.0], l: [-9, 2.5, 0] },
    { t: 15.20, p: [-2, 4.4, 11], l: [0, 3.6, 0] },
    { t: 15.85, p: [0, 4.8, 12], l: [0, 4.0, 0] },
  ] },
  { from: 15.85, to: 20.26, world: 'C', keys: [
    { t: 15.85, p: [-13, 7.5, 21], l: [0, 4, 0] },
    { t: 16.60, p: [-4, 4.6, 12], l: [3.4, 2.9, 3] },
    { t: 17.90, p: [-6, 6.2, 14.5], l: [0, 5.2, -1] },
    { t: 18.90, p: [-1, 4.8, 10.5], l: [0, 3.8, 1] },
    { t: 20.26, p: [-1.4, 3.7, 7.4], l: [-1, 3.0, 2] },
  ] },
  { from: 20.26, to: 25.19, world: 'D', keys: [
    { t: 20.26, p: [0, 12.5, 27], l: [0, 8, 0] },
    { t: 21.30, p: [4, 5.4, 12.5], l: [0, 4.6, 0] },
    { t: 22.40, p: [4.2, 3.4, 9.5], l: [0, 2.4, 0] },
    { t: 23.70, p: [-6, 7.0, 14], l: [0, 6.0, 0] },
    { t: 24.60, p: [-4, 8.5, 15], l: [0, 7.0, 0] },
    { t: 25.19, p: [0, 9.2, 17], l: [0, 6.6, 0] },
  ] },
  { from: 25.19, to: 32.80, world: 'E', keys: [
    { t: 25.19, p: [-7, 13, 21], l: [0, 0, -7] },
    { t: 26.10, p: [-3.5, 8, 11.5], l: [0, -1, -7] },
    { t: 26.80, p: [4.5, 5.5, 2], l: [1.5, 0.3, -7] },
    { t: 27.90, p: [10, 7, -1], l: [0, -1, -9] },
    { t: 28.70, p: [6, 5.2, 6], l: [-2, -0.5, -9] },
    { t: 30.00, p: [-1, 8, 4], l: [-10, 0, -4] },
    { t: 31.50, p: [3, 10, -2], l: [9, 0, -13] },
    { t: 32.80, p: [6, 13, 4], l: [6, 0, -12] },
  ] },
  { from: 32.80, to: 38.43, world: 'F', keys: [
    { t: 32.80, p: [-4, 5.2, 14], l: [0, 3.2, 3] },
    { t: 34.00, p: [4, 3.9, 9], l: [10, 0.5, -1] },
    { t: 35.34, p: [6, 4.4, 8], l: [6, 0.4, 0] },
    { t: 36.40, p: [-1, 3.6, 10.5], l: [-6, 2.6, 3.8] },
    { t: 37.60, p: [-10, 3.0, 7], l: [-18, 0.3, -2] },
    { t: 38.43, p: [-14, 2.7, 5.5], l: [-22, 0.3, -3] },
  ] },
  { from: 38.43, to: 43.20, world: 'G', keys: [
    { t: 38.43, p: [-8, 10.5, 18], l: [0, -3, -4] },
    { t: 39.40, p: [-4, 7.2, 14], l: [0, -1.5, -4] },
    { t: 40.80, p: [2, 5.6, 12], l: [0, 0, -6] },
    { t: 42.00, p: [6, 4.4, 9], l: [3, 0, -8] },
    { t: 43.20, p: [8, 4.1, 8], l: [5, 0.2, -9] },
  ] },
  { from: 43.20, to: 48.11, world: 'H', keys: [
    { t: 43.20, p: [-6.5, 5.2, 14], l: [0, 2.6, -2] },
    { t: 45.10, p: [-3, 4.4, 11.5], l: [0, 2.4, -1] },
    { t: 47.00, p: [1, 4.6, 11.5], l: [0, 3.0, 0] },
    { t: 48.11, p: [1.5, 4.7, 11], l: [0, 3.2, 0] },
  ] },
  { from: 48.11, to: 51.71, world: 'I', keys: [
    { t: 48.11, p: [-3.2, 6.2, 12], l: [0, 2.4, -1] },
    { t: 49.40, p: [-0.9, 3.5, 5.8], l: [0.4, 2.5, 0] },
    { t: 50.30, p: [0.8, 3.3, 4.7], l: [1.2, 2.4, 0.1] },
    { t: 51.71, p: [1.3, 3.1, 4.1], l: [1.2, 2.3, 0.1] },
  ] },
  { from: 51.71, to: 54.80, world: 'H', keys: [
    { t: 51.71, p: [7, 2.6, 7], l: [8.5, 1.2, 1] },
    { t: 53.20, p: [4.5, 5.2, 15], l: [4.5, 1.6, -2] },
    { t: 54.80, p: [0, 10.5, 29], l: [0, 1, -10] },
  ] },
];

// monotone cubic time warp (zero speed at the first and last key)
export function warpU(T, t) {
  const n = T.length; if (t <= T[0]) return 0; if (t >= T[n - 1]) return 1;
  const sec = []; for (let i = 0; i < n - 1; i++) sec.push((1 / (n - 1)) / (T[i + 1] - T[i]));
  const m = [0]; for (let i = 1; i < n - 1; i++) m.push(2 * sec[i - 1] * sec[i] / (sec[i - 1] + sec[i])); m.push(0);
  let i = 0; while (t > T[i + 1]) i++;
  const h = T[i + 1] - T[i], x = (t - T[i]) / h, x2 = x * x, x3 = x2 * x;
  return (2 * x3 - 3 * x2 + 1) * (i / (n - 1)) + (x3 - 2 * x2 + x) * h * m[i] + (-2 * x3 + 3 * x2) * ((i + 1) / (n - 1)) + (x3 - x2) * h * m[i + 1];
}

const curves = PATHS.map(P => ({
  P,
  T: P.keys.map(k => k.t),
  pc: new THREE.CatmullRomCurve3(P.keys.map(k => new THREE.Vector3(...k.p)), false, 'centripetal'),
  lc: new THREE.CatmullRomCurve3(P.keys.map(k => new THREE.Vector3(...k.l)), false, 'centripetal'),
}));

export function shotAt(t) {
  for (let i = CUTS.length - 1; i >= 0; i--) if (t >= CUTS[i].t0) return CUTS[i];
  return CUTS[0];
}
let cache = { f: -1, v: null };
export function camAt(frame) {
  if (cache.f === frame) return cache.v;
  const t = Math.min(frame / FPS, DURATION_S - 0.001);
  let c = curves.find(c => t >= c.P.from && t < c.P.to) || curves[curves.length - 1];
  const u = warpU(c.T, Math.max(c.P.from, Math.min(c.P.to, t)));
  const p = c.pc.getPoint(u), l = c.lc.getPoint(u);
  const x = WX[c.P.world];
  const v = { pos: [p.x + x, p.y, p.z], look: [l.x + x, l.y, l.z], world: c.P.world, t };
  cache = { f: frame, v };
  return v;
}
