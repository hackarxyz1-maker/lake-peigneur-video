import React, { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { AbsoluteFill, Audio, staticFile, useCurrentFrame, interpolate } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { useThree, useFrame } from '@react-three/fiber';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { BokehPass } from 'three/examples/jsm/postprocessing/BokehPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { CREAM, skyTex } from './kit.js';
import { CUTS, camAt, shotAt, FPS, W, H, WX } from './camera.js';
import { WorldA, WorldB, WorldC, WorldD, WorldE, WorldF, WorldG, WorldH, WorldI } from './worlds.jsx';

// per-location look: fog colour, sky, light
const LOOK = {
  A: { fog: '#e8dcc0', top: '#9ccbd9', bot: '#f4e6c8', key: '#fff0d2', ki: 2.6 },
  B: { fog: '#3a2c2a', top: '#3a2c2a', bot: '#3a2c2a', key: '#ffe2b8', ki: 2.0 },
  C: { fog: '#e6dcc2', top: '#92c3d6', bot: '#f2e2c4', key: '#fff0d2', ki: 2.6 },
  D: { fog: '#2c2424', top: '#2c2424', bot: '#2c2424', key: '#ffe6c0', ki: 2.1 },
  E: { fog: '#dcd2b8', top: '#7fb3c9', bot: '#efdcbc', key: '#ffe8c2', ki: 2.5 },
  F: { fog: '#e6dcc0', top: '#98c8d6', bot: '#f4e4c4', key: '#fff0d2', ki: 2.6 },
  G: { fog: '#e2d4b8', top: '#8fbfce', bot: '#f2e0c0', key: '#fff0d2', ki: 2.6 },
  H: { fog: '#eadcc0', top: '#9ccbd9', bot: '#f6e6c6', key: '#fff0d2', ki: 2.6 },
  I: { fog: '#cdbd98', top: '#9fc9d8', bot: '#f2e3c6', key: '#ffe6c0', ki: 2.2 },
};
const WORLDS = { A: WorldA, B: WorldB, C: WorldC, D: WorldD, E: WorldE, F: WorldF, G: WorldG, H: WorldH, I: WorldI };

const VignetteShader = {
  uniforms: { tDiffuse: { value: null }, uAmt: { value: 0.32 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
  fragmentShader: 'uniform sampler2D tDiffuse; uniform float uAmt; varying vec2 vUv; void main(){ vec4 c = texture2D(tDiffuse, vUv); float d = distance(vUv, vec2(0.5)); c.rgb *= 1.0 - uAmt * smoothstep(0.32, 0.85, d); gl_FragColor = c; }',
};

function Rig({ frame }) {
  const { gl, scene, camera, size } = useThree();
  const cam = camAt(frame);
  const look = LOOK[cam.world];
  const sh = shotAt(cam.t);
  const composer = useMemo(() => {
    const rt = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, samples: 4 });
    const c = new EffectComposer(gl, rt);
    c.setPixelRatio(1); c.setSize(W, H);
    const rp = new RenderPass(scene, camera); c.addPass(rp);
    const bokeh = new BokehPass(scene, camera, { focus: 10, aperture: 0.00035, maxblur: 0.006 }); c.addPass(bokeh);
    const vg = new ShaderPass(VignetteShader); c.addPass(vg);
    c.addPass(new OutputPass());
    c.userBokeh = bokeh;
    return c;
  }, [gl, scene, camera]);
  const keyRef = useRef();
  const sky = useMemo(() => skyTex(look.top, look.bot, 3), [cam.world]);
  // camera
  camera.fov = 80; camera.near = 0.3; camera.far = 400; camera.aspect = W / H;
  camera.position.set(...cam.pos); camera.lookAt(...cam.look); camera.updateProjectionMatrix(); camera.updateMatrixWorld();
  scene.fog = new THREE.Fog(look.fog, 38, 120); scene.background = new THREE.Color(look.fog);
  const focus = Math.hypot(cam.pos[0] - cam.look[0], cam.pos[1] - cam.look[1], cam.pos[2] - cam.look[2]);
  composer.userBokeh.uniforms.focus.value = focus;
  composer.userBokeh.uniforms.aspect.value = W / H;
  // warm key light from the upper left, following the location so shadows stay sharp
  const wx = WX[cam.world];
  useEffect(() => { if (keyRef.current) { keyRef.current.target.position.set(wx, 0, 0); keyRef.current.target.updateMatrixWorld(); } }, [wx]);
  useFrame(() => { composer.render(); }, 1);
  const warm = cam.world === 'H' && cam.t > 51.7 ? 1 : 0;
  return (<>
    <mesh position={cam.pos} renderOrder={-10}><sphereGeometry args={[250, 24, 16]} /><meshBasicMaterial map={sky} side={THREE.BackSide} depthWrite={false} fog={false} toneMapped={false} /></mesh>
    <hemisphereLight args={[warm ? '#ffd9a8' : '#dfeaf0', '#8a7456', 1.15]} />
    <directionalLight ref={keyRef} color={warm ? '#ffb877' : look.key} intensity={look.ki} position={[wx - 22, 34, 22]} castShadow shadow-mapSize={[2048, 2048]}
      shadow-camera-left={-34} shadow-camera-right={34} shadow-camera-top={34} shadow-camera-bottom={-34} shadow-camera-near={1} shadow-camera-far={110} shadow-bias={-0.0006} />
  </>);
}

export const Full = () => {
  const frame = useCurrentFrame();
  const cam = camAt(frame);
  const t = frame / FPS;
  const sh = shotAt(t);
  // 0.4 s dip to cream where the location changes
  let dip = 0;
  CUTS.forEach((c, i) => {
    if (i === 0 || CUTS[i - 1].world === c.world) return;
    const d = Math.abs(t - c.t0); if (d < 0.2) dip = Math.max(dip, 1 - d / 0.2);
  });
  const Active = WORLDS[sh.world];
  return (
    <AbsoluteFill style={{ backgroundColor: CREAM }}>
      <ThreeCanvas width={W} height={H} shadows gl={{ antialias: false, alpha: false, powerPreference: 'high-performance', toneMapping: THREE.NoToneMapping }} camera={{ fov: 80, near: 0.3, far: 400, position: cam.pos }}>
        <Rig frame={frame} />
        <Active />
      </ThreeCanvas>
      <AbsoluteFill style={{ backgroundColor: CREAM, opacity: dip, pointerEvents: 'none' }} />
      <Audio src={staticFile('mix.wav')} />
    </AbsoluteFill>
  );
};
